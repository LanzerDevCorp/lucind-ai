lucind-lane: 20261006-053850-ec5e turn: 1

## Skills to load before work
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-cli/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-testing/SKILL.md
/home/lanzerdev/.agents/skills/go-testing/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-code-style/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-error-handling/SKILL.md

# Move dispatch policy out of the CLI and delete the deprecated check command

## Goal

`cmd/lucind-ai` should only parse flags and print. Move dispatch policy into `internal/dispatch`,
remove shallow pass-throughs, and delete the deprecated `check` subcommand together with
`internal/check`.

Every stdout/stderr line and exit code of `dispatch`, `wait` and `accept` must stay byte-identical.
The only user-visible change allowed is that `lucind-ai check` no longer exists.

## Feature document

odd/tasks/dispatch-outcome.md

Read it before editing. Do not edit it; the orchestrator keeps it up to date.

## Current state (evidence)

- `cmd/lucind-ai/cli.go:403-427`: on an auto-skills failure the CLI decides and prints the reason,
  the "no lane was created. Fallback: ..." line, the missing-key line and the rejected-key line, then
  returns `ExitAutoSkillsUnavailable`.
- `cmd/lucind-ai/cli.go:334-367`: five copies of `usageBuf.Reset(); fs.Usage(); Fprint...` in
  `runDispatch`; `runWait` (`:444` onward) repeats the block and its positional-argument parsing.
- `internal/dispatch/model.go`: `ResolveModel` only wraps `executor.ResolveModel` (called at
  `dispatch.go:188`; tested in `model_test.go`).
- `internal/dispatch/wait.go:130`: `Wait(..., runner HerdrRunner)` never uses `runner`.
- `internal/dispatch/wait.go:76-122`: returns literal `3` and `4`; the constants `ExitError`,
  `ExitFailed`, `ExitTimeout`, `ExitAutoSkillsUnavailable` live in `internal/dispatch/skills.go:19-22`.
- `internal/dispatch/dispatch.go:26,214`: `Options.Brief` and a fallback to it, left over from the
  removed `--brief` flag; the CLI never sets it.
- `cmd/lucind-ai/cli.go:27,73,93-174`: deprecated `check` subcommand (usage line, case, `runCheck`,
  `formatMechanicalLog`), the only user of `internal/check`. Check whether `resolveCommitSHA` has other
  users before deleting it.
- Docs mentioning the subcommand: `README.md:23`, `docs/attestation.md:71`, `CLAUDE.md:27`.

## Scope

1. In `internal/dispatch`, add a function or method that returns the remediation lines for an
   auto-skills failure (reason line, fallback line, and the missing-key or rejected-key line when
   applicable), handling both `*AutoSkillsUnavailableError` and `ErrAutoSkillsUnavailable`. The CLI
   prints those lines unchanged and returns the exit code. Text must be identical.
2. In the CLI, one helper for "print message + usage, return exit code" replaces every repeated usage
   block in `runDispatch` and `runWait`; deduplicate `runWait`'s positional parsing.
3. Delete `internal/dispatch/model.go` and call `executor.ResolveModel` directly. Delete
   `model_test.go` only after confirming `internal/executor` tests cover the same cases (flag wins,
   env var, default); if a case is missing there, move it into `internal/executor` tests.
4. Drop the unused `runner` parameter from `dispatch.Wait` and update callers.
5. Move the exit code constants to `internal/dispatch/exitcodes.go` and use them in `wait.go`.
6. Remove `Options.Brief` and its fallback.
7. Delete the `check` subcommand (usage line, case, `runCheck`, `formatMechanicalLog`, now-unused
   helpers and imports) and the whole `internal/check` package with its tests. Delete CLI tests that
   only cover `check`. Keep `lucind-checks.sh`.
8. Docs: remove the `check` row from `README.md`; in `docs/attestation.md:71` say the subcommand was
   removed; in `CLAUDE.md:27` drop "and is what the deprecated `lucind-ai check` calls" and keep the
   rest of the paragraph (the script stays and must stay in sync with the check table).

Out of scope: `lucind-checks.sh`, `openspec/**`, behavior of other subcommands, `internal/executor`
code (tests there may gain cases per item 3).

## Acceptance criteria

- Unit tests in `internal/dispatch` cover the remediation lines for: missing key, rejected key,
  generic `*AutoSkillsUnavailableError`, and bare `ErrAutoSkillsUnavailable`.
- Existing `dispatch`, `wait` and `accept` CLI tests pass WITHOUT editing their assertions. Tests of
  deleted code are deleted with it; list each deleted or mechanically edited test file in the envelope
  with the reason. Never change an assertion to fit new behavior; fix the code instead.
- The rg checks under Verification print nothing.

## Allowed edit surfaces

cmd/lucind-ai/**
internal/dispatch/**
internal/check/**
internal/executor/*_test.go
README.md
docs/attestation.md
CLAUDE.md

## Hard stops

- Stop if keeping any `dispatch`/`wait`/`accept` output or exit code identical is impossible.
- Stop if the change requires editing files outside the allowed edit surfaces.

## Test-first policy

Runner: `go test`. Write the `internal/dispatch` remediation tests first and observe them fail (RED,
the function does not exist yet), then implement (GREEN), then move the CLI onto it while the existing
CLI tests stay green. Deletions need no RED. Report observed RED and GREEN output in the envelope.

## Verification

- `go test ./internal/dispatch ./internal/executor ./cmd/... -race -count=1`
- `rg -n 'internal/check|runCheck|dispatch\.ResolveModel|\bBrief\b' --type go internal/dispatch cmd` (must print nothing; `skillselect.Input{Brief:` in `cmd/lucind-ai/skills.go` is a different field, exclude it with `| rg -v 'skillselect.Input'`)
- `rg -n 'return .*, [134], ' internal/dispatch/wait.go` (must print nothing)
- `test ! -e internal/check`
- `gofmt -l internal cmd` (must print nothing)
- `golangci-lint run`
- `CGO_ENABLED=0 go build ./...`
- `go test ./... -race -count=1`

## Known environmental failures

`TestLaneIDFormat` can fail once in a full run (known flaky); rerun it before treating it as a failure.

## Language contract

Generated technical artifacts (code, comments, tests, docs) are in English. Exported identifiers get doc comments.

## Size heuristic

About 400 authored changed lines (additions plus deletions) is a planning heuristic only, not an
acceptance criterion or cap. Deleting `internal/check` alone will exceed it; that is expected. Never
remove blank lines or comments to save lines, omit tests, or add gratuitous abstractions.

## Key Learnings

After writing the result envelope, close your final response with a `## Key Learnings` block of
1-5 numbered standalone factual sentences (at least 4 words each), or omit it if there is nothing reusable.

---
## Lane Contract
- Lane ID: 20261006-053850-ec5e
- Allowed globs:
  - cmd/lucind-ai/**
  - internal/dispatch/**
  - internal/check/**
  - internal/executor/*_test.go
  - README.md
  - docs/attestation.md
  - CLAUDE.md
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261006-053850-ec5e/result-1.json` following the result schema.
- As the final verification, after your last edit, run these commands exactly as listed and do not edit files afterwards:
  - `lucind-ai attest run -- sh -c 'golangci-lint run'`
  - `lucind-ai attest run -- sh -c 'CGO_ENABLED=0 go build ./...'`
  - `lucind-ai attest run -- sh -c 'go test ./... -race -count=1'`
  - `lucind-ai attest run -- sh -c 'test -z "$(gofmt -l internal cmd)"'`
- Do not edit outside the allowed globs.
