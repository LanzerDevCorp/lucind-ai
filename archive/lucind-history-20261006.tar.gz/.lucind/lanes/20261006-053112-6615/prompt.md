lucind-lane: 20261006-053112-6615 turn: 1

## Skills to load before work
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-structs-interfaces/SKILL.md
/home/lanzerdev/.agents/skills/go-testing/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-testing/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-code-style/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-naming/SKILL.md

# A repo module that owns git, and a seam for accept

## Goal

Git calls about the repository and its trees are spread across `attest`, `accept` and the CLI.
Concentrate them in a new deep module `internal/repo`, and give `accept` a small seam so its verdict
logic can be tested without a git repository.

This is a pure refactor: command outputs, messages, exit codes, receipts and tree hash values must
stay identical.

## Feature document

odd/tasks/repo-module.md

Read it before editing. Do not edit it; the orchestrator keeps it up to date.

## Current state (evidence)

- `internal/attest/attest.go:175` `RepoToplevel` (`git rev-parse --show-toplevel`), `:195`
  `RepoCommonDir` (`--git-common-dir`), `:281-318` `TreeHash` (temp index via `GIT_INDEX_FILE`,
  `rev-parse --verify HEAD`, `read-tree HEAD` when HEAD exists, `add -A`, `write-tree`).
  `RepoID`, keys, entries, `FindValidAttestation`, `HasValidAttestation`, `Verify`, `RunAndRecord`
  are attestation concerns and stay in `attest`.
- `internal/accept/accept.go:57` runs `git diff --name-only <base> <final>` itself and calls
  `attest.TreeHash`.
- `cmd/lucind-ai/cli.go:176-200` has `resolveCommitSHA` (`git rev-parse HEAD`) and `gitShowToplevel`
  (`git rev-parse --show-toplevel`), duplicating `attest`.
- Callers of `attest.RepoToplevel`/`RepoCommonDir`/`TreeHash` outside `attest`: `internal/lane/lane.go`,
  `internal/dispatch/dispatch.go`, `internal/dispatch/wait.go`, `internal/agyhook/agyhook.go`,
  `internal/accept/accept.go`, `cmd/lucind-ai/{attest.go,cli.go,skills.go}`, and tests including
  `internal/accept/accept_test.go`.

## Scope

### Part 1: `internal/repo`

1. Create `internal/repo` with (adjust names to fit): `Toplevel(ctx, dir)`, `CommonDir(ctx, dir)`,
   `TreeHash(ctx, root)`, `ChangedFiles(ctx, root, base, final) ([]string, error)`, `HeadSHA(ctx, dir)`.
   Move the existing implementations; keep error message text identical where callers surface it
   (for example `git diff %s..%s: ...`, `git write-tree: ...`).
2. Remove `RepoToplevel`, `RepoCommonDir` and `TreeHash` from `attest`'s exported surface; `attest`
   calls `repo` where it needs them.
3. Migrate every caller listed above, and replace the CLI's `resolveCommitSHA`/`gitShowToplevel` with
   `repo`. Watch for differences: the CLI helpers run git without `-C`, in the process cwd; keep
   the same effective directory.
4. Tests in `internal/repo` use real temporary git repos (`t.TempDir()` + `git init`) and cover:
   tracked change, untracked file included, ignored file excluded, repo without HEAD (no commits),
   `ChangedFiles` between two tree hashes, `Toplevel` from a subdirectory.

### Part 2: seam in `accept`

5. `accept` depends on a small interface with two methods: compute the tree hash and list the files
   changed between two trees. Production uses an adapter backed by `internal/repo`. Exported `accept`
   entry points (`Accept`, `Run`) keep their current signatures and use the real adapter; add an
   unexported or clearly-named variant that takes the interface, for tests.
6. Add verdict tests in `internal/accept` on a fake adapter (no git): changed file outside the Allowed
   globs is rejected, `.lucind` state files are ignored, all files in scope with a done result and no
   checks is accepted. Keep the existing real-git `accept` tests as they are.

Out of scope: accept's check runner (`sh -c`), the attestation format, CLI flags or output,
`internal/check`.

## Acceptance criteria

- The rg checks under Verification print nothing.
- Existing tests pass WITHOUT editing their assertions. Mechanical edits (a moved function's package
  name, e.g. `attest.TreeHash` → `repo.TreeHash` in test setup) are allowed; list every edited test
  file and why in the envelope. Never change a test to fit new behavior; fix the code instead.
- `gofmt -l internal cmd` prints nothing.
- All verification commands pass.

## Allowed edit surfaces

internal/repo/**
internal/attest/**
internal/lane/**
internal/dispatch/**
internal/agyhook/**
internal/accept/**
cmd/lucind-ai/**

## Hard stops

- Stop if keeping outputs, messages or tree hash values identical is impossible.
- Stop if the change requires editing files outside the allowed edit surfaces.

## Test-first policy

Runner: `go test`. Write `internal/repo` tests first and observe them fail (RED, package/functions
missing), then move the implementations (GREEN). Write the `accept` fake-adapter tests before
introducing the seam (RED), then add it (GREEN). Report observed RED and GREEN output in the envelope.

## Verification

- `go test ./internal/repo ./internal/attest ./internal/accept ./internal/lane ./internal/dispatch ./internal/agyhook ./cmd/... -race -count=1`
- `rg -n '"git"' --type go -g '!*_test.go' internal cmd | rg -v '^internal/repo/'` (must print nothing)
- `rg -n 'attest\.(RepoToplevel|RepoCommonDir|TreeHash)\b' --type go internal cmd` (must print nothing)
- `gofmt -l internal cmd` (must print nothing)
- `golangci-lint run`
- `CGO_ENABLED=0 go build ./...`
- `go test ./... -race -count=1`

## Known environmental failures

`TestLaneIDFormat` can fail once in a full run (known flaky); rerun it before treating it as a failure.

## Language contract

Generated technical artifacts (code, comments, tests) are in English. Exported identifiers get doc comments.

## Size heuristic

About 400 authored changed lines (additions plus deletions) is a planning heuristic only, not an
acceptance criterion or cap. If the correct, clear solution exceeds it, say why and continue. Never
remove blank lines or comments to save lines, omit tests, or add gratuitous abstractions.

## Key Learnings

After writing the result envelope, close your final response with a `## Key Learnings` block of
1-5 numbered standalone factual sentences (at least 4 words each), or omit it if there is nothing reusable.

---
## Lane Contract
- Lane ID: 20261006-053112-6615
- Allowed globs:
  - internal/repo/**
  - internal/attest/**
  - internal/lane/**
  - internal/dispatch/**
  - internal/agyhook/**
  - internal/accept/**
  - cmd/lucind-ai/**
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261006-053112-6615/result-1.json` following the result schema.
- As the final verification, after your last edit, run these commands exactly as listed and do not edit files afterwards:
  - `lucind-ai attest run -- sh -c 'golangci-lint run'`
  - `lucind-ai attest run -- sh -c 'CGO_ENABLED=0 go build ./...'`
  - `lucind-ai attest run -- sh -c 'go test ./... -race -count=1'`
  - `lucind-ai attest run -- sh -c 'test -z "$(gofmt -l internal cmd)"'`
- Do not edit outside the allowed globs.
