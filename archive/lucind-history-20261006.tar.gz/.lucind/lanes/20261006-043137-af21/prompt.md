lucind-lane: 20261006-043137-af21 turn: 2

# Follow-up turn: fix a behavior regression

The first turn is close, but review found a behavior change that the refactor must not introduce.
Fix it in this turn. The full original task follows below; its constraints still apply.

## Review findings

1. **Re-running `accept` on a lane that already has a verdict now fails.** `Lane.RecordVerdict` in
   `internal/lane/lifecycle.go` refuses lanes whose status is `accepted` or `rejected`. Before the
   refactor, `accept` could run again on the same lane (for example, rejected for a missing
   attestation, then the check is attested and `accept` runs again and accepts). You changed
   `internal/accept/accept_test.go` to accept a second, new lane instead, which hides the regression.
   - Restore that test so it re-accepts the SAME lane (`l.ID`) as before.
   - Make `RecordVerdict` allow `accepted`/`rejected` → `accepted`/`rejected` (re-review), while
     still rejecting invalid statuses and invalid verdicts.
   - Add table rows in `internal/lane/lifecycle_test.go` for rejected → accepted and accepted → rejected.
2. **Error text changed.** A failed legacy rename used to surface as `rename previous result: ...`
   from dispatch; it now says `rename legacy result:` wrapped in `begin continuation turn ...`.
   Keep the original `rename previous result:` wording in `BeginTurn` and restore the
   `internal/dispatch/dispatch_test.go` assertion to match `rename previous result:`.

Do not change test assertions to fit new behavior anywhere else; if another test needed changing
for a behavior reason, revert it and fix the code instead, and list it in the envelope.

---

# Deepen the Lane module into the lifecycle owner

## Goal

Make `internal/lane` own the lane lifecycle. Today `lane.Lane` is a plain record with `Load`/`Save`
and four other packages change its fields directly, so the rules for legal status changes and the
retry budget are scattered. Move every transition behind `internal/lane` methods that check the move
is legal and persist it. The callers become thin.

This is a pure refactor: observable behavior, exit codes, file names, hook output and the on-disk
`lane.json` contents must stay the same.

## Feature document

odd/tasks/lane-lifecycle.md

Read it before editing. Do not edit it; the orchestrator keeps it up to date.

## Current state (evidence)

- `internal/dispatch/dispatch.go:197-256` and `:303`: continuation turn setup (`Turn` increment,
  terminal-lane guard at ~:202, legacy `result.json` → `result.prev.json` rename at ~:235, reset of
  `Retries`/`Continues`/`LastStopAt`, `Status = StatusRunning`, `Allow`/`Checks` replacement), then `Save`.
- `internal/dispatch/wait.go:72-126`: sets `StatusTimeout` and saves in four places; calls
  `lane.MarkStopped`.
- `internal/agyhook/agyhook.go:333-391`: Stop handling with the retry/continue budget
  (`Retries`, `Continues`, `LastStopAt`, quiet window), `Save`, and `lane.MarkStopped`.
- `internal/accept/accept.go:130-136` and `:156`: sets `StatusAccepted`/`StatusRejected` and saves.
- `internal/lane/lane.go:328`: `MarkStopped`. `internal/lane/status.go`: deprecated aliases
  `Running`, `Done`, `Failed`, `Pending`, `Blocked`, `Deviated` (no users anywhere).

## Scope

1. In `internal/lane`, add lifecycle methods. Suggested shape (adjust names to fit the code):
   - begin a continuation turn (new allow globs/checks optional; refuses a lane whose status does not
     allow continuing; performs the legacy result rename and the counter resets);
   - record a Stop and decide continue/retry vs. stop, owning the retry and continue budget and the
     quiet window that agyhook holds today (keep the limits and timing identical);
   - mark a lane timed out;
   - record the review verdict (accepted/rejected).
   Each method validates the transition, updates `UpdatedAt`, and saves atomically.
   Return a clear error for an illegal transition.
2. Migrate `dispatch`, `wait`, `agyhook` and `accept` to these methods. After the change, no
   non-test code outside `internal/lane` assigns `Status`, `Retries`, `Continues`, `LastStopAt` or
   `Turn` on a `lane.Lane`. Creating a new lane in dispatch may keep using the existing constructor/`Create`.
3. Remove the deprecated status aliases from `internal/lane/status.go`.
4. Keep `MarkStopped` only if it still has a role; otherwise fold it into the new methods.

Out of scope: shared `CurrentResult`/`InScope` helpers beyond what the transitions need, a git seam,
CLI changes (`cmd/**`), `lane.json` schema changes, docs.

## Acceptance criteria

- Table-driven tests in `internal/lane` cover legal and illegal transitions for each method,
  including the retry/continue budget edges.
- The rg check below finds no field assignments outside `internal/lane` (excluding `_test.go`).
- Existing tests in `internal/dispatch`, `internal/agyhook` and `internal/accept` pass, changed only
  where they reached into fields the refactor now hides.
- All verification commands pass.

## Allowed edit surfaces

internal/lane/**
internal/dispatch/**
internal/agyhook/**
internal/accept/**

## Hard stops

- Stop if keeping behavior identical would require changing the `lane.json` schema or any file name.
- Stop if the change requires editing files outside the allowed edit surfaces.

## Test-first policy

Runner: `go test`. Write the transition table tests in `internal/lane` first and observe them fail
(RED, they reference methods that do not exist yet), then implement (GREEN), then migrate callers
while the existing caller tests stay green. Report the observed RED and GREEN output in the envelope.

## Verification

- `go test ./internal/lane ./internal/dispatch ./internal/agyhook ./internal/accept -race -count=1`
- `rg -n '\.(Status|Retries|Continues|LastStopAt|Turn)\s*=[^=]' --type go -g '!*_test.go' internal cmd | rg -v '^internal/lane/'` (must print nothing)
- `golangci-lint run`
- `CGO_ENABLED=0 go build ./...`
- `go test ./... -race -count=1`

## Known environmental failures

`TestLaneIDFormat` can fail once in a full run (known flaky); rerun it before treating it as a failure.

## Language contract

Generated technical artifacts (code, comments, tests) are in English.

## Size heuristic

About 400 authored changed lines (additions plus deletions) is a planning heuristic only, not an
acceptance criterion or cap. If the correct, clear solution exceeds it, say why and continue. Never
remove blank lines or comments to save lines, omit tests, or add gratuitous abstractions.

## Key Learnings

After writing the result envelope, close your final response with a `## Key Learnings` block of
1-5 numbered standalone factual sentences (at least 4 words each), or omit it if there is nothing reusable.

---
## Lane Contract
- Lane ID: 20261006-043137-af21
- Allowed globs:
  - internal/lane/**
  - internal/dispatch/**
  - internal/agyhook/**
  - internal/accept/**
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261006-043137-af21/result-2.json` following the result schema.
- As the final verification, after your last edit, run these commands exactly as listed and do not edit files afterwards:
  - `lucind-ai attest run -- sh -c 'golangci-lint run'`
  - `lucind-ai attest run -- sh -c 'CGO_ENABLED=0 go build ./...'`
  - `lucind-ai attest run -- sh -c 'go test ./... -race -count=1'`
- Do not edit outside the allowed globs.
