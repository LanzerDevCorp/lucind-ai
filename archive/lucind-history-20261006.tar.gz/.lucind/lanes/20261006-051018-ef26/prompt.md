lucind-lane: 20261006-051018-ef26 turn: 1

## Skills to load before work
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-testing/SKILL.md
/home/lanzerdev/.agents/skills/go-testing/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-structs-interfaces/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-code-style/SKILL.md

# One home for the current Result envelope and the lane scope rule

## Goal

Two pieces of lane knowledge are re-derived at each call site. Move each into `internal/lane` behind
one function and migrate every caller:

1. Reading the current turn's Result envelope and checking that its status is `"done"`.
2. Deciding whether a repository-relative path is inside the lane's code scope: it matches an
   Allowed glob and is not lane state (`.lucind` or anything under it).

This is a pure refactor: PreToolUse hook decisions and messages, `accept` reasons text, `wait`
outputs and exit codes, and file names must stay exactly the same.

## Feature document

odd/tasks/lane-result-scope.md

Read it before editing. Do not edit it; the orchestrator keeps it up to date.

## Current state (evidence)

- Result read + done check: `internal/lane/lifecycle.go:105,168` (RecordStop) and `:224,227`
  (MarkStopped); `internal/dispatch/wait.go:73-74` and `:80-82`; `internal/accept/accept.go:41-50`,
  which builds the path by hand with `filepath.Join(".lucind","lanes",laneID,...)` against the repo
  root instead of using `lane.LaneDir`. `accept` distinguishes missing (`fs.ErrNotExist`) from
  schema-invalid and includes the read error in its reason text; `RecordStop` uses the read error text
  for the retry message.
- Scope rule: `internal/agyhook/agyhook.go:205` denies a write when the path is outside the repo, is
  `.lucind` or under it, or matches no Allowed glob (the current turn's result path is allowed just
  before, at `:198`). `internal/accept/accept.go:76-82` skips changed files that are `.lucind` or under
  it, and rejects the rest that match no Allowed glob. Same rule, two copies.
- `internal/result/result.go:2` doc comment still says the envelope lives at `.lucind/result.json`;
  it is now `.lucind/lanes/<id>/result-<turn>.json` (or legacy `result.json` for turn 0).

## Scope

1. In `internal/lane`, add a current-turn result accessor. Suggested shape (adjust to fit the code):
   a method on `Lane` taking the repo root and returning the envelope, an outcome
   (missing / invalid / not done / done) and the read error, so callers keep their exact messages.
2. In `internal/lane`, add `IsStatePath(rel string) bool` and `InScope(l Lane, rel string) bool`
   (or a method), operating on slash-separated repo-relative paths.
3. Migrate `lifecycle.go`, `wait.go`, `accept.go` and `agyhook.go` to these functions. `accept`
   must stop building the lane path by hand.
4. Fix the stale doc comment in `internal/result/result.go` (comment only, no code change there).

Out of scope: a git seam, CLI changes (`cmd/**`), schema or file name changes, any message change.

## Acceptance criteria

- Table-driven tests in `internal/lane` for the result accessor: turn 0 with legacy `result.json`,
  turn N with `result-<N>.json`, missing, schema-invalid, valid but not done, done. And for
  `IsStatePath`/`InScope`: `.lucind`, `.lucind/x`, `.lucindx/y` (not state), matching and
  non-matching globs.
- The two `rg` checks under Verification print nothing.
- Existing tests in `internal/dispatch`, `internal/agyhook`, `internal/accept` pass WITHOUT editing
  their assertions. Do not change an existing test to fit new behavior; if one fails, fix the code.
  If a test must change for a purely mechanical reason (a renamed unexported helper), say so in the
  envelope with the reason.

## Allowed edit surfaces

internal/lane/**
internal/dispatch/**
internal/agyhook/**
internal/accept/**
internal/result/result.go

## Hard stops

- Stop if keeping behavior and messages identical is impossible without changing a schema or file name.
- Stop if the change requires editing files outside the allowed edit surfaces.

## Test-first policy

Runner: `go test`. Write the new table tests in `internal/lane` first and observe them fail (RED,
the functions do not exist yet), then implement (GREEN), then migrate callers while existing caller
tests stay green. Report the observed RED and GREEN output in the envelope.

## Verification

- `go test ./internal/lane ./internal/dispatch ./internal/agyhook ./internal/accept -race -count=1`
- `rg -n 'result\.Read\(' --type go -g '!*_test.go' internal cmd | rg -v '^internal/(lane|result)/'` (must print nothing)
- `rg -n '"\.lucind"' --type go -g '!*_test.go' internal/agyhook internal/accept internal/dispatch` (must print nothing)
- `golangci-lint run`
- `CGO_ENABLED=0 go build ./...`
- `go test ./... -race -count=1`

## Known environmental failures

`TestLaneIDFormat` can fail once in a full run (known flaky); rerun it before treating it as a failure.

## Language contract

Generated technical artifacts (code, comments, tests) are in English.

## Size heuristic

About 400 authored changed lines (additions plus deletions) is a planning heuristic only, not an
acceptance criterion or cap. If the correct, clear solution exceeds it, say why and continue. Never
remove blank lines or comments to save lines, omit tests, or add gratuitous abstractions.

## Key Learnings

After writing the result envelope, close your final response with a `## Key Learnings` block of
1-5 numbered standalone factual sentences (at least 4 words each), or omit it if there is nothing reusable.

---
## Lane Contract
- Lane ID: 20261006-051018-ef26
- Allowed globs:
  - internal/lane/**
  - internal/dispatch/**
  - internal/agyhook/**
  - internal/accept/**
  - internal/result/result.go
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261006-051018-ef26/result-1.json` following the result schema.
- As the final verification, after your last edit, run these commands exactly as listed and do not edit files afterwards:
  - `lucind-ai attest run -- sh -c 'golangci-lint run'`
  - `lucind-ai attest run -- sh -c 'CGO_ENABLED=0 go build ./...'`
  - `lucind-ai attest run -- sh -c 'go test ./... -race -count=1'`
- Do not edit outside the allowed globs.
