lucind-lane: 20261005-183907-f159 turn: 1

## Skills to load before work
/home/lanzerdev/.agents/skills/tdd/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-cli/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-testing/SKILL.md
/home/lanzerdev/.agents/skills/go-testing/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-error-handling/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-structs-interfaces/SKILL.md

# Global API key lookup, install-time key setup, and two skill variants

## Feature document

odd/tasks/global-api-key-and-skill-variants.md

Read it before editing: it holds the decisions D1-D8, the tasks T1-T4 and the acceptance criteria.
Do not rewrite its checklist; report proposed changes with reasons in your result instead.

## Allowed edit surfaces
internal/userconfig/userconfig.go
internal/userconfig/userconfig_test.go
internal/skillselect/jev.go
internal/skillselect/jev_test.go
internal/skillselect/select_test.go
internal/dispatch/skills.go
internal/dispatch/skills_test.go
internal/claudeplugin/claudeplugin.go
internal/claudeplugin/claudeplugin_test.go
internal/claudeplugin/variant.go
internal/claudeplugin/variant_test.go
cmd/lucind-ai/install.go
cmd/lucind-ai/install_test.go
cmd/lucind-ai/keyprompt.go
cmd/lucind-ai/keyprompt_test.go
cmd/lucind-ai/skills.go
cmd/lucind-ai/skills_test.go
plugin/claude-code/skills/lucind/SKILL.md
README.md
docs/product.md
docs/skill-selection.md
docs/ROADMAP.md

## Goal

Today `TYPESAFE_API_KEY` is read only with `os.Getenv` (`skillselect.KeyFromEnv`,
`internal/skillselect/jev.go`), so every dispatch needs the caller to export it, and with an empty
key `dispatch --auto-skills` only warns and continues without a skills section. Make the key a
one-time setup stored in a user config file, and make the installed Claude skill match whether the
key is configured.

## Required behavior

1. **T1, config and lookup.** New package `internal/userconfig` (standard library only):
   - `Dir()`: `$XDG_CONFIG_HOME/lucind` when `XDG_CONFIG_HOME` is set and non-empty, otherwise
     `~/.config/lucind` (via `os.UserHomeDir`). `EnvFile()` is `Dir()/env`.
   - `ReadKey(name)`: parse the file as dotenv-style lines `NAME=value`. Tolerate blank lines,
     `#` comments, a leading `export `, and one pair of single or double quotes around the value;
     trim whitespace. A missing file returns an empty value and no error. Any other read error is
     returned wrapped, without the value in it.
   - `WriteKey(name, value)`: create the directory with mode 0700 and the file with mode 0600; when
     the file exists, replace or append only that one line and keep every other line byte for byte;
     the write is atomic (temp file in the same directory, then rename).
   - In `skillselect`, replace `KeyFromEnv` with `ResolveKey()`: the environment variable first
     (non-empty), then `userconfig.ReadKey("TYPESAFE_API_KEY")`. Update every caller and test
     (`internal/dispatch/skills.go`, `cmd/lucind-ai/skills.go`, tests).
   - The missing-key message in both places becomes
     `lucind-ai: TYPESAFE_API_KEY is not set; export it or run lucind-ai install to store it in ~/.config/lucind/env`
     (dispatch keeps its warn-and-continue behavior, only the text changes). Adapt the tests that
     assert the old text; never delete them.
   - The key value must never appear in any error, log line, warning or test output.
2. **T2, skill variants.** `plugin/claude-code/skills/lucind/SKILL.md` stays the single source. Mark
   the parts that differ with HTML comment blocks, each on its own lines:
   `<!-- lucind:variant manual -->` ... `<!-- /lucind:variant -->` and
   `<!-- lucind:variant auto -->` ... `<!-- /lucind:variant -->`. Unmarked text is common to both.
   - `auto` variant (key configured): the orchestrator is NOT obliged to write
     `## Skills to load before work`; the lane dispatch usage always includes `--auto-skills`
     (not in brackets) and the skill states that lucind-ai selects and inserts the skills section
     first in the prompt. A hand-written section is only for forcing a specific skill.
   - `manual` variant (no key): the current behavior, the orchestrator resolves the exact
     `SKILL.md` paths itself and writes the section; `--auto-skills` is not listed, and the
     skill says it needs the key and a re-run of `lucind-ai install` once the key is configured.
   - Update the `## Setup` section (common) to mention the key, `~/.config/lucind/env`, and that
     the variant is chosen at install time, so adding the key later needs `lucind-ai install` again.
   - In `internal/claudeplugin` add a `Variant` type (`VariantManual`, `VariantAuto`) and a render
     step that, when copying the embedded tree, keeps the selected blocks, drops the other ones,
     and removes the marker lines. Keep the existing `Install`, `InstallHome` and `InstallDir`
     working and defaulting to `VariantManual`; add variant-taking siblings (for example
     `InstallVariant`, `InstallHomeVariant`). Only `SKILL.md` is rendered. An unbalanced or unknown
     marker must be an error, not silently ignored.
3. **T3, install flow** in `cmd/lucind-ai/install.go`, before the skill step:
   - If `skillselect.ResolveKey()` returns a key, ask nothing and use the auto variant.
   - Otherwise, when stdin is a terminal, prompt on stderr
     `TYPESAFE_API_KEY (selects skills with Jev; press Enter to skip): ` and read the answer
     without echo using `stty -echo` on the terminal (restore with `stty echo` in a defer; if
     `stty` is missing, say that the input will be visible and read it normally). A non-empty
     answer is stored with `userconfig.WriteKey` and selects the auto variant; an empty one skips
     and selects the manual variant.
   - Otherwise (no terminal) do not block and do not write anything: select the manual variant and
     print one line to stdout that says no key is configured, how to set it (run `lucind-ai install`
     in a terminal, or put `TYPESAFE_API_KEY=...` in `~/.config/lucind/env`), and that
     re-running install switches the skill.
   - Never overwrite an existing key and never copy the key from the environment to disk.
   - The skill line reports the variant: `installed claude skill (auto-skills variant) into <dir>`
     or `(manual variant)`. Keep the rest of the install sequence and its exit codes unchanged.
   - Put the terminal check, the hidden read and the writer behind small package-level function
     variables (the file already uses `claudeInstall`, `claudemdInstall` and `userHomeDir` this way)
     so tests never need a real terminal or `stty`. Put the prompt code in `cmd/lucind-ai/keyprompt.go`.
4. **T4, docs.** Update `README.md`, `docs/product.md` and `docs/skill-selection.md` to describe the
   key lookup order, `~/.config/lucind/env`, the install-time prompt and the two skill variants. In
   `docs/ROADMAP.md` add a Done entry for this feature and remove the open bullet that says
   lucind-ai could load the repo `.env` itself.

## Test-first policy

Runner: `go test`. For each behavior write the failing test first and observe RED, then GREEN, then
refactor with tests green: `userconfig` parsing (quotes, `export`, comments, missing file, other
lines preserved), file and directory modes 0600 and 0700, atomic replace, `ResolveKey` order
(environment over file), variant rendering for both variants and the error cases, and the install
flow cases (key resolves so no prompt and auto variant; no key with a terminal so prompt, store and
auto variant; empty answer so manual variant; no terminal so manual variant and exit 0; existing key
never overwritten). Never invent RED/GREEN evidence.

## Test isolation (critical)

A real `~/.config/lucind/env` will exist on the machine that runs these tests, so any test that
expects "no key", and every install test, must set `XDG_CONFIG_HOME` to `t.TempDir()` (and clear
`TYPESAFE_API_KEY` with `t.Setenv(..., "")`). No test may read or write the real home directory or
the real config file. Add a small shared helper per package if that keeps the tests readable.

## Hard stops
Stop and report `blocked` if a change is needed in a file outside the allowed edit surfaces.
Stop and report `blocked` if the work would need a new module dependency.
Never print, log or store the key anywhere other than the 0600 config file written by `WriteKey`.
Never commit, stage, push, or delete files; the orchestrator commits.

## Verification
golangci-lint run
CGO_ENABLED=0 go build ./...
go test ./... -race -count=1

## Known environmental failures
`TestLaneIDFormat` is flaky in a full run; repeat it before blaming the change.

## Language contract
Code, comments, tests, docs, and user-facing messages are English.

## Size heuristic
About 400 authored changed lines per task is a planning heuristic only, not a cap. This change
naturally spans several packages with tests; say why if it exceeds it and continue. Never delete
blank lines or comments to save lines, never omit tests.

## Report in the result envelope
Per task T1-T4: what changed and the evidence. List the skill files you opened before your first
edit, and which of them you passed to any worker subagent you launched (or state that you launched
none). Report the exact RED and GREEN test names you observed, and the final `skills_loaded` field
of this envelope must list the skill files you actually read.

## Key Learnings
After writing your normal result envelope, close your final response text with a
`## Key Learnings` block of 1-5 numbered items, each a standalone factual sentence of at least 20
characters and at least 4 words. Omit the block if there is genuinely no reusable learning.

---
## Lane Contract
- Lane ID: 20261005-183907-f159
- Allowed globs:
  - internal/userconfig/userconfig.go
  - internal/userconfig/userconfig_test.go
  - internal/skillselect/jev.go
  - internal/skillselect/jev_test.go
  - internal/skillselect/select_test.go
  - internal/dispatch/skills.go
  - internal/dispatch/skills_test.go
  - internal/claudeplugin/claudeplugin.go
  - internal/claudeplugin/claudeplugin_test.go
  - internal/claudeplugin/variant.go
  - internal/claudeplugin/variant_test.go
  - cmd/lucind-ai/install.go
  - cmd/lucind-ai/install_test.go
  - cmd/lucind-ai/keyprompt.go
  - cmd/lucind-ai/keyprompt_test.go
  - cmd/lucind-ai/skills.go
  - cmd/lucind-ai/skills_test.go
  - plugin/claude-code/skills/lucind/SKILL.md
  - README.md
  - docs/product.md
  - docs/skill-selection.md
  - docs/ROADMAP.md
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261005-183907-f159/result-1.json` following the result schema.
- As the final verification, after your last edit, run these commands exactly as listed and do not edit files afterwards:
  - `lucind-ai attest run -- sh -c 'golangci-lint run'`
  - `lucind-ai attest run -- sh -c 'CGO_ENABLED=0 go build ./...'`
  - `lucind-ai attest run -- sh -c 'go test ./... -race -count=1'`
- Do not edit outside the allowed globs.
