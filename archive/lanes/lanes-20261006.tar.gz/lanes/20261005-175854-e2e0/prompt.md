lucind-lane: 20261005-175854-e2e0 turn: 1

## Skills to load before work
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-testing/SKILL.md
/home/lanzerdev/.agents/skills/go-testing/SKILL.md
/home/lanzerdev/.agents/skills/tdd/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-code-style/SKILL.md
/home/lanzerdev/.agents/skills/implement/SKILL.md

# Add prompt-layout edge-case tests through ConstructPrompt

## Goal

`ConstructPrompt` in `internal/dispatch/dispatch.go` builds the text dispatch sends to agy: the lane
marker line, then the `## Skills to load before work` section moved to the top, then the rest of the
user prompt, then the contract footer. Add table-driven tests for its layout edge cases in
`internal/dispatch/dispatch_test.go`. Do not change production code.

## Constraints

All tests in this package live in the external package `dispatch_test`, and the helper that splits
out the skills section (`extractSkillsSection`) is unexported. Test it only through the exported
`ConstructPrompt`; never export a helper and never add an internal test file. Read the existing
`TestConstructPrompt` (around line 519) and `TestAutoSkills_SectionPlacement` in
`internal/dispatch/skills_test.go` first, and add only cases they do not already cover.

## Allowed edit surfaces
internal/dispatch/dispatch_test.go

## Cases to cover (skip any already covered, and say which)
- no skills section: the marker line, then the trimmed prompt, then the footer
- skills section first, followed by other headings
- skills section in the middle: text before and after it is rejoined in order with one blank line
- skills section at the very end of the prompt
- a blank line inside the section ends it (current behavior; assert it, do not change it)
- CRLF line endings and trailing spaces on the heading line
- a heading that only looks similar (for example `## Skills to load`) is not treated as the section
- in every case the marker line is line 1 and the footer is last

## Test-first policy
Runner: `go test ./internal/dispatch -run ConstructPrompt -count=1`. These tests cover existing
behavior, so GREEN on the first run is expected for most cases. If a case fails, that is a real
finding: do not edit production code; mark that case with `t.Skip` plus a reason and describe it in
the result envelope. Never invent RED/GREEN evidence.

## Hard stops
Stop and report `blocked` if a test needs a change outside the allowed edit surfaces.
Never commit, stage, push, or delete files.

## Verification
go test ./internal/dispatch -race -count=1
golangci-lint run

## Language contract
Code, comments and test names are English.

## Report in the result envelope
Which skill files you opened before your first edit (list them), which of your skill files you
passed on to any worker subagent you launched (list them, or state that you launched none), the case
table you added, which listed cases were already covered, and any case that exposed unexpected
behavior.

## Key Learnings
After writing your normal result envelope, close your final response text with a
`## Key Learnings` block of 1-5 numbered items, each a standalone factual sentence of at least 20
characters and at least 4 words. Omit the block if there is genuinely no reusable learning.

---
## Lane Contract
- Lane ID: 20261005-175854-e2e0
- Allowed globs:
  - internal/dispatch/dispatch_test.go
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261005-175854-e2e0/result-1.json` following the result schema.
- As the final verification, after your last edit, run these commands exactly as listed and do not edit files afterwards:
  - `lucind-ai attest run -- sh -c 'go test ./internal/dispatch -race -count=1'`
  - `lucind-ai attest run -- sh -c 'golangci-lint run'`
- Do not edit outside the allowed globs.
