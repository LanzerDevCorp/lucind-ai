lucind-lane: 20261005-174913-ea48 turn: 1

## Skills to load before work
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-testing/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-code-style/SKILL.md

# Add edge-case tests for extractSkillsSection

## Goal

`extractSkillsSection` in `internal/dispatch/dispatch.go` splits a prompt into its
`## Skills to load before work` section and the rest. Add table-driven tests for its edge cases in
`internal/dispatch/dispatch_test.go`. Do not change production code.

## Allowed edit surfaces
internal/dispatch/dispatch_test.go

## Cases to cover
- no skills section: returns an empty section and the trimmed prompt
- skills section first, followed by other headings
- skills section in the middle: text before and after is rejoined in order with one blank line
- skills section at the very end of the prompt
- a blank line inside the section ends it (the current behavior; assert it, do not change it)
- CRLF line endings and trailing spaces on the heading line
- a heading that only looks similar (for example `## Skills to load`) is not treated as the section

## Test-first policy
Runner: `go test ./internal/dispatch -run ExtractSkillsSection -count=1`. These tests cover existing
behavior, so GREEN on the first run is expected for most cases. If a case fails, that is a real
finding: do not edit production code, record it under the result envelope instead and mark that case
with `t.Skip` plus a reason. Never invent RED/GREEN evidence.

## Hard stops
Stop and report `blocked` if a test needs a change outside the allowed edit surfaces.
Never commit, stage, push, or delete files.

## Verification
go test ./internal/dispatch -race -count=1
golangci-lint run

## Language contract
Code, comments and test names are English.

## Report in the result envelope
Which skill files you opened before editing (list them), the case table you added, and any case that
exposed unexpected behavior.

## Key Learnings
After writing your normal result envelope, close your final response text with a
`## Key Learnings` block of 1-5 numbered items, each a standalone factual sentence of at least 20
characters and at least 4 words. Omit the block if there is genuinely no reusable learning.

---
## Lane Contract
- Lane ID: 20261005-174913-ea48
- Allowed globs:
  - internal/dispatch/dispatch_test.go
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261005-174913-ea48/result-1.json` following the result schema.
- As the final verification, after your last edit, run these commands exactly as listed and do not edit files afterwards:
  - `lucind-ai attest run -- sh -c 'go test ./internal/dispatch -race -count=1'`
  - `lucind-ai attest run -- sh -c 'golangci-lint run'`
- Do not edit outside the allowed globs.
