# Direct-prompt dispatch: remove the "Read and follow brief.md" pointer and `--brief`

## Skills to load before work
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-cli/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-testing/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-code-style/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-error-handling/SKILL.md

## Feature document
odd/tasks/direct-prompt-dispatch.md

Read it before editing: it holds the decisions D1-D4, the scope, and tasks T1-T4. Do not
rewrite its checklist; report proposed changes with reasons in your result instead.

## Allowed edit surfaces
internal/dispatch/dispatch.go
internal/dispatch/dispatch_test.go
internal/dispatch/skills_test.go
internal/agyhook/agyhook.go
internal/agyhook/agyhook_test.go
cmd/lucind-ai/cli.go
cmd/lucind-ai/cli_test.go
cmd/lucind-ai/skills.go
cmd/lucind-ai/skills_test.go
internal/agyplugin/assets/rules/lucind-lane.md
internal/agyplugin/assets/skills/lucind-result/SKILL.md
plugin/claude-code/skills/lucind/SKILL.md
README.md
docs/product.md
docs/skill-selection.md
docs/ROADMAP.md

## Goal

Today `lucind-ai dispatch` writes `.lucind/lanes/<id>/brief.md` and sends agy the pointer prompt
`Read and follow <abs>/brief.md` (`internal/dispatch/dispatch.go`, around line 245). agy does not
follow it: it skips the `## Skills to load before work` files and does not pass them to its worker
subagents. Make dispatch send the task content itself as the prompt, and remove `--brief`.

## Required behavior

1. **Direct prompt (T1).** The text sent to agy is the whole prompt, never a pointer to a file.
   Layout, in order:
   - Line 1, the lane marker, exactly: `lucind-lane: <laneID> turn: <n>`
   - then, when the user prompt contains a `## Skills to load before work` section (hand-written or
     the auto-selected one), that section moved to come right after the marker line, before any
     other content;
   - then the rest of the user prompt;
   - then the existing contract footer (lane id, allowed globs, result path, check commands).
   Keep the existing `constructBrief` content rules (footer, per-turn result path). Rename the
   function to match its new role (for example `constructPrompt` / `ConstructPrompt`) and update
   callers and tests.
2. **Record only.** Persist the exact final prompt to `.lucind/lanes/<id>/prompt.md` (replaces
   `brief.md`). Nothing in the prompt sent to agy may mention this file.
3. **Resend guard.** `sendPrompt` takes a `marker` string used to detect that the prompt already
   reached the pane before re-sending. Pass the lane marker line (`lucind-lane: <id> turn: <n>`)
   instead of the old brief path.
4. **CLI (T2).** Replace `--brief <file|->` with `--prompt <file|->` in `dispatch` and in
   `skills select`. Update both usage strings (`cli.go`, `skills.go`) and every flag description.
   Passing `--brief` must exit non-zero with a clear message that points to `--prompt`
   (not Go's generic "flag provided but not defined"). No alias, no deprecation period.
5. **Hook (T3).** `classifyConversation` in `internal/agyhook/agyhook.go` (around lines 250-254)
   matched the main conversation by `Read and follow` plus `.lucind/lanes/<id>/brief.md`. Replace
   it: a conversation is main when its transcript step 0 has source empty or `USER_EXPLICIT` and
   its content contains `lucind-lane: <laneID>`. Keep the worker detection and the role cache
   unchanged. Do not touch anything else in the hook (ROADMAP item 3 stays open on purpose).
6. **Docs and assets (T4).** Update every remaining mention so the repository reads consistently:
   the agy rule `internal/agyplugin/assets/rules/lucind-lane.md` (it tells agy to read `brief.md`
   first: change it to say the task is the prompt itself, and keep the `## Lane Contract` and
   result-envelope guidance), `internal/agyplugin/assets/skills/lucind-result/SKILL.md`,
   `plugin/claude-code/skills/lucind/SKILL.md` (usage lines, "Writing a brief" section: rename to
   writing the prompt, `--prompt`, skills section first, and state that the prompt is sent directly),
   `README.md`, `docs/product.md`, `docs/skill-selection.md`. In `docs/ROADMAP.md` move item 4 plan
   step 1 to a Done entry ("direct prompt dispatch") and leave plan steps 2 and 3 as open.
   Historical material (`openspec/`, `odd/`, `.lucind/`, `archive/`) is never edited.

## Test-first policy

Runner: `go test`. For each behavior change write the failing test first and observe RED, then
GREEN, then refactor with tests green: the prompt layout (marker first, skills section moved up,
footer last), `prompt.md` persisted and `brief.md` not written, the `sendPrompt` marker, the
`--brief` rejection message in both commands, and the hook classification. Existing tests that
assert the old strings must be adapted, not deleted. Never invent RED/GREEN evidence.

## Hard stops
Stop and report `blocked` if a change is needed in a file outside the allowed edit surfaces.
Stop and report `blocked` if making the hook classify main conversations by the marker would
require touching anything in the hook other than `classifyConversation` and its tests.
Never commit, stage, push, or delete files; the orchestrator commits.

## Verification
golangci-lint run
CGO_ENABLED=0 go build ./...
go test ./... -race -count=1
rg -n 'Read and follow|brief\.md|--brief' --glob '!.lucind/**' --glob '!.codegraph/**' --glob '!openspec/**' --glob '!odd/**' --glob '!archive/**' --glob '!docs/ROADMAP.md'

## Known environmental failures
`TestLaneIDFormat` is flaky in a full run; repeat it before blaming the change.

## Language contract
Code, comments, tests, docs and error messages are English.

## Size heuristic
About 400 authored changed lines per task is a planning heuristic only, not a cap. This change
naturally spans many files with many test updates; say why if it exceeds it and continue. Never
delete blank lines or comments to save lines, never omit tests.

## Report in the result envelope
Per task T1-T4: what changed and the evidence. For the final `rg` check, report any remaining match
and justify it. Report the exact RED and GREEN test names you observed.

## Key Learnings
After writing your normal result envelope, close your final response text with a
`## Key Learnings` block of 1-5 numbered items, each a standalone factual sentence of at least 20
characters and at least 4 words. Omit the block if there is genuinely no reusable learning.

---
## Lane Contract
- Lane ID: 20261005-171421-9331
- Allowed globs:
  - internal/dispatch/dispatch.go
  - internal/dispatch/dispatch_test.go
  - internal/dispatch/skills_test.go
  - internal/agyhook/agyhook.go
  - internal/agyhook/agyhook_test.go
  - cmd/lucind-ai/cli.go
  - cmd/lucind-ai/cli_test.go
  - cmd/lucind-ai/skills.go
  - cmd/lucind-ai/skills_test.go
  - internal/agyplugin/assets/rules/lucind-lane.md
  - internal/agyplugin/assets/skills/lucind-result/SKILL.md
  - plugin/claude-code/skills/lucind/SKILL.md
  - README.md
  - docs/product.md
  - docs/skill-selection.md
  - docs/ROADMAP.md
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261005-171421-9331/result-1.json` following the result schema.
- As the final verification, after your last edit, run these commands exactly as listed and do not edit files afterwards:
  - `lucind-ai attest run -- sh -c 'golangci-lint run'`
  - `lucind-ai attest run -- sh -c 'CGO_ENABLED=0 go build ./...'`
  - `lucind-ai attest run -- sh -c 'go test ./... -race -count=1'`
- Do not edit outside the allowed globs.
