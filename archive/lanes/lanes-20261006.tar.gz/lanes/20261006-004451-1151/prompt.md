lucind-lane: 20261006-004451-1151 turn: 1

## Skills to load before work
/home/lanzerdev/.agents/skills/tdd/SKILL.md
/home/lanzerdev/.agents/skills/go-testing/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-testing/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-cli/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-concurrency/SKILL.md
/home/lanzerdev/.agents/skills/implement/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-code-style/SKILL.md

# Bind the main conversation with a PreInvocation hook

Replace the transcript-based main/worker classification in the agy Stop hook with a binding that
lucind-ai owns. Read `odd/tasks/main-conversation-binding.md` before editing: it holds the problem,
the measured evidence, the design and the acceptance criteria. Do not edit that file.

## Allowed edit surfaces
internal/agyhook/**
internal/agyplugin/**
cmd/lucind-ai/hook.go
cmd/lucind-ai/hook_test.go
docs/ROADMAP.md
docs/product.md

## Task 1: binding and Stop classification
1. Add `agyhook.PreInvocation(ctx, laneID, stdin) []byte`, same signature style as `PreToolUse` and `Stop`.
   - It always returns `{}` (never injects steps) and never fails the agent: empty lane id, invalid lane id,
     bad JSON or any I/O error all return `{}`.
   - It loads the lane (`lane.Load`) to read the current `Turn`, then creates
     `<laneDir>/main-turn-<turn>` with `os.OpenFile(..., O_WRONLY|O_CREATE|O_EXCL, 0o644)` and writes the
     payload's `conversationId` into it. If the file already exists it does nothing. This makes the first
     `PreInvocation` of a turn win without racing on `lane.json`. Ignore an empty conversation id.
   - Log one line with `logf` when a binding is created.
2. Add the `pre-invocation` case to `hookDispatch` in `cmd/lucind-ai/hook.go` and update its usage text.
3. Add a `PreInvocation` entry to `internal/agyplugin/assets/hooks.json.tmpl`. It is a flat array like `Stop`:
   `{"type": "command", "command": "__LUCIND_BIN__ hook pre-invocation"}`. The rendered file must stay valid JSON.
4. Rewrite the role decision in `Stop`:
   - Read `<laneDir>/main-turn-<l.Turn>` (load the lane before classifying). Same conversation id is `roleMain`,
     a different id is `roleWorker`, a missing or empty file is `roleUnknown` (keep the existing `fullyIdle`
     fallback and its log line).
   - Delete `classifyConversation`, `transcriptStep`, `sanitizeConvID`, `getOrClassifyRole` and the
     `conversations/` cache, plus any import left unused. Nothing may read `transcriptPath` for classification.
5. Update `internal/agyhook/agyhook_test.go`: remove the transcript-based classification tests and add tests for
   the new behavior (first binding wins, second conversation does not rebind, a new turn binds again,
   concurrent first calls produce exactly one marker, PreInvocation returns `{}` for bad input, Stop ignores a
   worker, decides on the main conversation, and falls back when no marker exists). Add a template test in
   `internal/agyplugin/agyplugin_test.go` asserting the rendered `hooks.json` has `PreInvocation`.
   Add a small test in `cmd/lucind-ai/hook_test.go` for the new subcommand if no existing test file covers it.

## Task 2: docs
Update `docs/ROADMAP.md`: move item 3 from Next to Done as a new entry (`feature/main-conversation-binding`)
and renumber the remaining Next items. Record the measurement in one short paragraph: `PreInvocation`
fires for workers, the payload has no parent id or prompt text, the first event after dispatch is the main
conversation, `ANTIGRAVITY_CONVERSATION_ID` equals the hook's own id, and herdr exposes nothing per conversation.
Keep the accepted risk (a previous-turn worker emitting first). Update the hook description in `docs/product.md`.

## Test-first policy
Runner: `go test`. For each behavior, observe RED before implementing, then GREEN, then refactor. Report the
RED evidence in `done_criteria[].evidence`. Docs need only a structural check.

## Hard stops
Stop and report `blocked` if the change needs an edit outside the allowed edit surfaces.
Stop and report `blocked` if `lane.Load` cannot give the current turn without changing the lane schema.

## Verification
- `golangci-lint run`
- `CGO_ENABLED=0 go build ./...`
- `go test ./... -race -count=1`
- `rg -n 'transcriptPath|classifyConversation' internal/agyhook --glob '!*_test.go'`: no classification use left.

## Known environmental failures
`TestLaneIDFormat` is flaky in a full run; repeat it before blaming the change.

## Size heuristic
About 400 authored changed lines per task is a planning heuristic only, not an acceptance criterion or hard cap.
Never delete blank lines or comments to save lines and never omit tests.

## Language contract
Code, comments, tests and docs are in English.

## Key Learnings
After the result envelope, close your final response with a `## Key Learnings` block of 1-5 numbered items,
each a standalone factual sentence of at least 20 characters and at least 4 words.

---
## Lane Contract
- Lane ID: 20261006-004451-1151
- Allowed globs:
  - internal/agyhook/**
  - internal/agyplugin/**
  - cmd/lucind-ai/hook.go
  - cmd/lucind-ai/hook_test.go
  - docs/ROADMAP.md
  - docs/product.md
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261006-004451-1151/result-1.json` following the result schema.
- As the final verification, after your last edit, run these commands exactly as listed and do not edit files afterwards:
  - `lucind-ai attest run -- sh -c 'golangci-lint run'`
  - `lucind-ai attest run -- sh -c 'CGO_ENABLED=0 go build ./...'`
  - `lucind-ai attest run -- sh -c 'go test ./... -race -count=1'`
- Do not edit outside the allowed globs.
