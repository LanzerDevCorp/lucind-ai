lucind-lane: 20261005-192858-4de5 turn: 1

## Skills to load before work
/home/lanzerdev/.agents/skills/tdd/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-error-handling/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-cli/SKILL.md
/home/lanzerdev/.agents/skills/go-testing/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-testing/SKILL.md

# Fail closed when --auto-skills cannot select skills, with a manual fallback

## Feature document

odd/tasks/auto-skills-fail-closed.md

Read it before editing: it holds the decisions D1-D7, the scope, tasks T1-T4 and the acceptance
criteria. Do not rewrite its checklist; report proposed changes with reasons in your result instead.

## Allowed edit surfaces
internal/dispatch/dispatch.go
internal/dispatch/skills.go
internal/dispatch/dispatch_test.go
internal/dispatch/skills_test.go
cmd/lucind-ai/cli.go
cmd/lucind-ai/cli_test.go
plugin/claude-code/skills/lucind/SKILL.md
internal/claudeplugin/claudeplugin_test.go
internal/claudeplugin/variant_test.go
README.md
docs/product.md
docs/skill-selection.md
docs/ROADMAP.md

## Goal

Today `dispatch --auto-skills` launches the lane even when the skills could not be selected: any
selector error only prints one stderr line (`handleAutoSkills`, `internal/dispatch/skills.go`).
With the `auto` skill variant the orchestrator no longer writes the skills section, so the lane
silently runs without skills. Make dispatch fail closed, and give the orchestrator a clean
fallback.

## Required behavior

1. **T1, selection before mutation.** In `internal/dispatch/dispatch.go` the lane is created (step 4,
   `lane.Create`) or, for a continuation (`--lane`), loaded, its `Turn` incremented and saved, BEFORE
   `handleAutoSkills` runs (step 5), and the pane is opened after that (step 6). Reorder it so that,
   when `opts.AutoSkills` is set, the selection runs first and NOTHING is written or opened if it
   fails:
   - Split `handleAutoSkills` into a selection phase and a recording phase. The selection phase
     takes the prompt and the allow globs and returns the section to insert (or none) plus the
     outcome, and it writes no file. The recording phase writes `skills-<turn>.json` once the lane
     exists, exactly as today for the successful and the non-failure cases.
   - The allow globs the selector receives are `opts.Allow`, or for a continuation without
     `--allow` the stored lane's globs. Read the stored lane without saving it to know them.
   - Define a typed error (for example `AutoSkillsUnavailableError` wrapping the cause, plus a
     sentinel such as `ErrAutoSkillsUnavailable` usable with `errors.Is`). Every selector error maps
     to it: missing key, HTTP errors including 401, network errors, a missing or unreadable
     registry. The cause text must stay redacted with the existing `redactAPIKey`; the key value
     never appears.
   - NOT failures, dispatch continues as today: the prompt already contains the
     `## Skills to load before work` section (the selector is not called, the record says
     `brief_has_section`, and no key is needed), or the selector ran and selected nothing (record
     `no_skill_selected`).
   - After a failed selection nothing may exist: no new lane directory, no `lane.json`, no
     `prompt.md`, no `skills-<turn>.json`, no pane split, no herdr call at all. For a continuation
     the stored `lane.json` must be byte-identical to before (turn and status unchanged).
2. **T2, CLI.** Add a new exit code 5, meaning "auto-skills unavailable, no lane was created", next
   to the existing ones (0 done, 1 error, 3 failed, 4 timeout); use a named constant like the
   others. The dispatch handler in `cmd/lucind-ai/cli.go` prints, on stderr and nothing on stdout:
   ```
   lucind-ai: auto-skills unavailable: <redacted reason>
   lucind-ai: no lane was created. Fallback: add a "## Skills to load before work" section with absolute SKILL.md paths to the prompt and dispatch again (a hand-written section skips Jev).
   ```
   and, only when the cause is a missing key, a third line:
   `lucind-ai: to store the key run lucind-ai install, or put TYPESAFE_API_KEY=... in ~/.config/lucind/env`.
   Update the usage text and every place that lists the exit codes.
3. **T3, skill.** In `plugin/claude-code/skills/lucind/SKILL.md` (single source with
   `<!-- lucind:variant manual|auto -->` blocks, rendered per variant) make these changes:
   - In the `auto` variant add a short fallback paragraph in the dispatch section: when dispatch
     exits 5, no lane exists; resolve the skills by hand with the procedure below, put the
     `## Skills to load before work` section in the prompt and dispatch again (keeping or dropping
     `--auto-skills` both work because a hand-written section wins); tell the user the reason when
     it is a key problem (missing or invalid key), pointing to `lucind-ai install`.
   - Move the how-to for resolving skills by hand (exact absolute `SKILL.md` paths, resolve
     symlinks, `.atl/skill-registry.md`) out of the `manual`-only block into common text, so both
     variants carry it: it is the primary path in `manual` and the fallback in `auto`.
   - Keep the exit code list in the skill correct (add 5).
   Adapt `internal/claudeplugin/claudeplugin_test.go` and `variant_test.go` only if they assert text
   that changed; do not delete assertions.
4. **T4, docs.** Update `README.md`, `docs/product.md` (the exit code line) and
   `docs/skill-selection.md` (fail closed, exit 5, the fallback). In `docs/ROADMAP.md` add a Done
   entry for this feature.

## Test-first policy

Runner: `go test`. Write the failing test first and observe RED, then GREEN, then refactor with the
tests green. Cover at least: selector error on a new lane returns exit 5 and the typed error, with
no lane directory, no `prompt.md`, no `skills-*.json` and zero herdr runner calls; selector error on a
continuation leaves `lane.json` byte-identical; missing key returns exit 5 and the third stderr line;
an HTTP 401 style error returns exit 5 and the key never appears in stderr or the error; a prompt with
a hand-written section dispatches with the selector never called, with and without `--auto-skills`,
and with no key configured; a selector returning no skills dispatches and records
`no_skill_selected`; the success case still writes `skills-<turn>.json` with `Injected: true`; the CLI
prints the guidance lines on stderr and nothing on stdout. Existing tests that lock the old
warn-and-continue behavior (`TestAutoSkills_SelectorError`, `TestAutoSkills_SelectorError_DefaultStderr`
and the missing-key cases in `internal/dispatch/skills_test.go`, plus any in `cmd/lucind-ai`) must be
adapted to the new contract, not deleted. Never invent RED/GREEN evidence.

## Test isolation

Every test that expects "no key" must set `XDG_CONFIG_HOME` to `t.TempDir()` and clear
`TYPESAFE_API_KEY` with `t.Setenv(..., "")`, because a real `~/.config/lucind/env` exists on the
machine that runs these tests. No test may read or write the real home directory.

## Hard stops
Stop and report `blocked` if a change is needed in a file outside the allowed edit surfaces.
Stop and report `blocked` if making the selection run before the lane mutation would require
changing the lane package (`internal/lane`).
Never print or log the API key. Never commit, stage, push, or delete files.

## Verification
golangci-lint run
CGO_ENABLED=0 go build ./...
go test ./... -race -count=1
test -z "$(gofmt -l cmd internal)"

## Known environmental failures
`TestLaneIDFormat` is flaky in a full run; repeat it before blaming the change.

## Language contract
Code, comments, tests, docs and user-facing messages are English.

## Size heuristic
About 400 authored changed lines per task is a planning heuristic only, not a cap. Say why if the
change exceeds it and continue. Never delete blank lines or comments to save lines, never omit tests.

## Report in the result envelope
Per task T1-T4: what changed and the evidence. List in `skills_loaded` the skill files you actually
read, and say which of them you passed on to any worker subagent you launched (or that you launched
none). Report the exact RED and GREEN test names you observed.

## Key Learnings
After writing your normal result envelope, close your final response text with a
`## Key Learnings` block of 1-5 numbered items, each a standalone factual sentence of at least 20
characters and at least 4 words. Omit the block if there is genuinely no reusable learning.

---
## Lane Contract
- Lane ID: 20261005-192858-4de5
- Allowed globs:
  - internal/dispatch/dispatch.go
  - internal/dispatch/skills.go
  - internal/dispatch/dispatch_test.go
  - internal/dispatch/skills_test.go
  - cmd/lucind-ai/cli.go
  - cmd/lucind-ai/cli_test.go
  - plugin/claude-code/skills/lucind/SKILL.md
  - internal/claudeplugin/claudeplugin_test.go
  - internal/claudeplugin/variant_test.go
  - README.md
  - docs/product.md
  - docs/skill-selection.md
  - docs/ROADMAP.md
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261005-192858-4de5/result-1.json` following the result schema.
- As the final verification, after your last edit, run these commands exactly as listed and do not edit files afterwards:
  - `lucind-ai attest run -- sh -c 'golangci-lint run'`
  - `lucind-ai attest run -- sh -c 'CGO_ENABLED=0 go build ./...'`
  - `lucind-ai attest run -- sh -c 'go test ./... -race -count=1'`
  - `lucind-ai attest run -- sh -c 'test -z "$(gofmt -l cmd internal)"'`
- Do not edit outside the allowed globs.
