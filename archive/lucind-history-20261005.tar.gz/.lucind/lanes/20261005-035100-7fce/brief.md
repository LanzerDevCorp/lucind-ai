# T2: `lucind-ai dispatch --auto-skills`

## Goal

Let `dispatch` fill the brief's `## Skills to load before work` section with the Jev skill
selector from T1 (`internal/skillselect`, already committed), so the orchestrator no longer reads
the skill registry. Opt-in through a new flag, and it must never make a dispatch fail.

## Feature document

odd/tasks/jev-skill-selector.md

Read it before editing (decisions D1-D7, T1 notes). Do not edit it; the orchestrator owns it.

## Scope

1. `internal/dispatch`: add `AutoSkills bool` to `Options`. In `Dispatch`, after the lane is
   created or continued (so `l.ID` and `l.Turn` are known) and before `constructBrief`
   (`internal/dispatch/dispatch.go:181`), when `AutoSkills` is set:
   - If the user brief already contains a line that is exactly `## Skills to load before work`
     (ignoring trailing whitespace), do not call Jev and keep the brief unchanged.
   - Otherwise call the selector through a package-level function variable (the same injection
     style as `ensureAgyQuota` / `SetEnsureAgyQuotaForTesting`), whose default implementation:
     opens `<repoRoot>/.atl/skill-registry.md`, `skillselect.ParseRegistry`,
     `skillselect.KeyFromEnv()` (error when empty), `skillselect.NewClient`, and
     `skillselect.Select` with `skillselect.Input{Brief: opts.Brief, Allow: l.Allow}` and
     `skillselect.DefaultThreshold`.
   - On success, when `skillselect.Section(result.Decisions)` is non-empty, append it to the
     user brief as its own section (separated by a blank line) before the lane contract is added.
   - On any selector error, warn once on stderr with
     `lucind-ai: auto-skills: <error>; dispatching without a skills section` and continue the
     dispatch unchanged. Choose how the warning reaches stderr following the package's existing
     style (for example a `Stderr io.Writer` in `Options` that the CLI sets, defaulting to
     discard), and never print the API key.
   - Always write `.lucind/lanes/<id>/skills-<turn>.json` (atomic write, like other lane files)
     with: `turn`, `injected` (bool), `skipped_reason` (`"brief_has_section"`, `"no_skill_selected"`
     or omitted), `error` (string, omitted on success), and `result` (the `skillselect.Result`,
     omitted when Jev was not called or failed). Put the file name helper next to
     `lane.ResultFileName` if that fits the package layout.
   - Without `--auto-skills`, behavior and files are exactly as today.
2. `cmd/lucind-ai/cli.go`: add the `--auto-skills` flag to `dispatch` and its usage line, and wire
   stderr for the warning.
3. Tests (`internal/dispatch/dispatch_test.go`, `cmd/lucind-ai/cli_test.go`), using the existing
   fake herdr runner and a fake selector (no network):
   - flag off: selector never called, no `skills-<turn>.json`;
   - brief already has the section: selector not called, brief unchanged, file records
     `brief_has_section`;
   - selector success with selected skills: the sent brief contains the section before the
     `## Lane Contract` footer, file records `injected: true` and the decisions;
   - selector success with no selected skill: brief unchanged, `no_skill_selected`;
   - selector error: dispatch still succeeds, warning on stderr, file records the error;
   - continuation turn (`--lane`) writes `skills-<turn>.json` for the new turn.
4. Docs:
   - `plugin/claude-code/skills/lucind/SKILL.md`: add `[--auto-skills]` to the dispatch synopsis;
     in "Brief sections", change the `## Skills to load before work` bullet to say that with
     `--auto-skills` the orchestrator omits the section and does not read the skill registry:
     lucind-ai asks Jev using `.atl/skill-registry.md` and `TYPESAFE_API_KEY`, records
     `skills-<turn>.json`, and a hand-written section always wins. Keep the manual rule for
     dispatches without the flag.
   - `docs/skill-selection.md`: add a section for `dispatch --auto-skills` and the
     `skills-<turn>.json` format.

## Allowed edit surfaces
internal/dispatch/dispatch.go
internal/dispatch/dispatch_test.go
internal/dispatch/skills.go
internal/dispatch/skills_test.go
internal/lane/lane.go
internal/lane/lane_test.go
cmd/lucind-ai/cli.go
cmd/lucind-ai/cli_test.go
plugin/claude-code/skills/lucind/SKILL.md
docs/skill-selection.md

## Skills to load before work
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-error-handling/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-testing/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-cli/SKILL.md

## Hard stops
Making a real network call to api.typesafe.ai.
Needing to edit a file outside the allowed edit surfaces.
Changing the behavior of dispatch when --auto-skills is not set.

## Verification
golangci-lint run
CGO_ENABLED=0 go build ./...
go test ./... -race -count=1

## Known environmental failures
TestLaneIDFormat can fail once in a full run (known flaky); re-run it before treating it as a failure.

## Test-first policy
When a relevant runnable deterministic test and a clear expected outcome exist, observe RED
before implementing, then GREEN, then refactor while tests stay green. Runner: `go test`. Report
the RED and GREEN observations you actually saw; never invent them.

## Language contract
Generated technical artifacts (code, comments, tests, fixtures, docs) are in English.

## Size heuristic
About 400 authored changed lines is a planning heuristic only, not a cap. If the correct, clear
solution exceeds it, say why and continue. Never minify, drop tests or split artificially.

## Key Learnings
After writing your result envelope, close your final response with a `## Key Learnings` block of
1-5 numbered items, each a standalone factual sentence of at least 20 characters and 4 words;
omit it when there is genuinely no reusable learning.

## Follow-up corrections (turn 2)

Turn 1 is mostly accepted and stays in the tree. Apply only these, with tests for each:

1. Fail open completely: `Dispatch` must never fail because of auto-skills. When writing
   `skills-<turn>.json` fails, warn on stderr (`lucind-ai: auto-skills: write skills record: <err>`)
   and continue with the brief computed so far. Remove the `return Output{}, 1, ...` branch in
   `internal/dispatch/dispatch.go` for auto-skills and make `handleAutoSkills` return only the brief.
2. Resolve symlinks of skill paths: lane workers are not Claude, and in this repo
   `.claude/skills/<name>` are symlinks to `../../.agents/skills/<name>` while the registry lists the
   `.claude` path. Add `skillselect.ResolvePaths(skills []Skill) []Skill` (in
   `internal/skillselect/registry.go`) that replaces each `Path` with `filepath.EvalSymlinks(Path)`
   and keeps the original path when that fails. Call it after `ParseRegistry` in both the dispatch
   default selector and `cmd/lucind-ai/skills.go`. Test it with a temp dir symlink and with a
   missing path.
3. Simplify `internal/dispatch/skills.go`: drop the `sync.RWMutex` and the exported
   `HasSkillsSection` wrapper; use a plain package-level variable with a `SetSkillSelectorForTesting`
   setter, matching `ensureAgyQuota` / `SetEnsureAgyQuotaForTesting` in `dispatch.go`.
4. `plugin/claude-code/skills/lucind/SKILL.md`: in the manual (no flag) wording, replace
   "(skill registry or `~/.claude/skills`)" with guidance to pass the real file path (resolve
   symlinks; for example `.agents/skills/<name>/SKILL.md`), since lane workers are not Claude.

---
## Lane Contract
- Lane ID: 20261005-035100-7fce
- Allowed globs:
  - internal/dispatch/dispatch.go
  - internal/dispatch/dispatch_test.go
  - internal/dispatch/skills.go
  - internal/dispatch/skills_test.go
  - internal/lane/lane.go
  - internal/lane/lane_test.go
  - internal/skillselect/registry.go
  - internal/skillselect/registry_test.go
  - cmd/lucind-ai/skills.go
  - cmd/lucind-ai/skills_test.go
  - cmd/lucind-ai/cli.go
  - cmd/lucind-ai/cli_test.go
  - plugin/claude-code/skills/lucind/SKILL.md
  - docs/skill-selection.md
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261005-035100-7fce/result-2.json` following the result schema.
- As the final verification, after your last edit, run these commands exactly as listed and do not edit files afterwards:
  - `lucind-ai attest run -- sh -c 'golangci-lint run'`
  - `lucind-ai attest run -- sh -c 'CGO_ENABLED=0 go build ./...'`
  - `lucind-ai attest run -- sh -c 'go test ./... -race -count=1'`
- Do not edit outside the allowed globs.
