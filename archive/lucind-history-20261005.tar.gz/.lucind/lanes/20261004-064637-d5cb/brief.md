# T7, T13, T14: dispatch footer polish, stale result on continuation, retry logging

Three small, related fixes in the lane machinery. Tasks T7, T13 and T14 of the feature document.
Do only these three.

## Feature document
odd/tasks/lane-checks-and-install.md

## Allowed edit surfaces
internal/dispatch/dispatch.go
internal/dispatch/dispatch_test.go
internal/agyhook/agyhook.go
internal/agyhook/agyhook_test.go

## Scope and design

Read the feature document first (the T9, T13 and T14 entries explain the evidence), then:

1. **T7, footer polish** (`constructBrief` in `internal/dispatch/dispatch.go`). With one or more
   checks, print a single intro line ("As the final verification, after your last edit, run these
   commands exactly as listed and do not edit files afterwards:") followed by one list item per
   check with `lucind-ai attest run -- sh -c '<check>'` (keep the existing safe shell quoting).
   With zero checks keep the current "no verification command required" notice. All other footer
   lines stay as they are.
2. **T13, stale result on continuation** (`Dispatch`, continuation branch for `--lane <id>`):
   before the new prompt is sent, if the lane's `result.json` exists, rename it to
   `result.prev.json` in the same lane directory (replacing a previous `result.prev.json`), so the
   Stop hook requires a fresh envelope instead of accepting the old one. A missing `result.json`
   is not an error; any other filesystem error is returned. A new (non-continuation) lane is
   unaffected.
3. **T14, retry logging** (`Stop` in `internal/agyhook/agyhook.go`): every time the hook spends a
   retry (the `invalid && l.Retries < MaxRetries` branch) call the existing `logf` with a line like
   `stop: retry <n>/<MaxRetries>: <reason>`, where the reason is the same text sent back to agy
   (`the file does not exist` or the validation error). Do not change when retries are spent,
   `MaxRetries`, or any other behavior.

Out of scope: any other file, `lane` package, `accept`, and deciding whether stops with a running
subagent should consume retries.

## Hard stops
- Any needed edit outside the allowed edit surfaces: stop with status `blocked` and say which path.

## Test-first policy
Runner: `go test`. Observe RED first, then GREEN, then refactor. Cover at least: footer with 0, 1
and N checks (intro line once, one item per check, quoting case still round-trips); continuation
renames an existing `result.json` to `result.prev.json`, replaces an older `.prev`, tolerates a
missing file, and a new lane does not touch anything; the Stop hook writes a retry log line with
the counter and the reason for a missing file and for an invalid file, and writes none when the
result is valid. Report RED and GREEN evidence per behavior in `done_criteria[].evidence`. Never
invent RED/GREEN evidence.

## Verification
go test ./...
go vet ./...
test -z "$(gofmt -l .)"

## Language contract
Code, comments, tests and docs are in English.

## Size heuristic
About 400 authored changed lines is a planning heuristic only, not a cap or stop condition.

## Constraints
Match the style of the surrounding code and keep every Go file `gofmt`-clean. Do not commit; the
parent commits after accept.

## Key Learnings
After writing the result envelope, persist your learnings with Engram `mem_save` and close your
final response with a `## Key Learnings` block of 1-5 numbered items, each a standalone factual
sentence of at least 20 characters and at least 4 words. Omit it when there is nothing reusable.

---
## Lane Contract
- Lane ID: 20261004-064637-d5cb
- Allowed globs:
  - internal/dispatch/dispatch.go
  - internal/dispatch/dispatch_test.go
  - internal/agyhook/agyhook.go
  - internal/agyhook/agyhook_test.go
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261004-064637-d5cb/result.json` following the result schema.
- As the final verification run exactly `lucind-ai attest run -- sh -c 'go test ./...'` and do not edit files afterwards.
- As the final verification run exactly `lucind-ai attest run -- sh -c 'go vet ./...'` and do not edit files afterwards.
- As the final verification run exactly `lucind-ai attest run -- sh -c 'test -z "$(gofmt -l .)"'` and do not edit files afterwards.
- Do not edit outside the allowed globs.
