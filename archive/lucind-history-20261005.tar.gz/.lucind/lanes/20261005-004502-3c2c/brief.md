# T2: lane model gets a turn counter and a per-turn result file

## Goal

Today a lane has a single `result.json`, so any valid envelope closes the lane no matter which turn wrote it.
This task adds the **model** for per-turn result files. Later tasks (T3 dispatch/wait, T4 hook/accept) will use it,
so this task must stay purely additive and the whole repo must keep compiling and passing.

## Feature document

Read `odd/tasks/turn-bound-results.md` before editing (objective, decisions, acceptance criteria).

## Required behavior

In `internal/lane/lane.go`:

- `Lane` gets a `Turn int` field persisted in `lane.json` as `"turn"`.
- `Create` sets `Turn` to 1 on every new lane.
- A lane loaded from an old `lane.json` without `turn` has `Turn == 0`. That is a **legacy lane** and keeps using `result.json`.
- Add `func ResultFileName(turn int) string`: returns `"result.json"` when `turn <= 0`, otherwise `fmt.Sprintf("result-%d.json", turn)`.
- Add `func ResultFilePath(root string, l Lane) string`: the lane directory joined with `ResultFileName(l.Turn)`. Follow the same
  relative/absolute convention the existing `ResultPath(root, id)` uses.
- Keep the existing `ResultPath(root, id string)` working exactly as today (other packages still call it until T4). Document it
  with a plain comment saying it is the legacy single-file path kept during the migration. Do NOT start that comment with
  `Deprecated:` (staticcheck SA1019 would then fail every caller and break `golangci-lint run`).
- `MarkStopped(root, id)` must read the result file of the lane's **current turn** (`ResultFilePath` of the loaded lane), not
  the legacy path. A valid `result-1.json` must be ignored when the lane is at turn 2.

Do not touch any other package. Do not change the result schema or the lane ID format.

## Allowed edit surfaces

internal/lane/lane.go
internal/lane/lane_test.go

## Hard stops

An existing exported function signature in internal/lane would have to change
A change is needed outside the allowed edit surfaces

## Test-first policy

Go tests exist and expected outcomes are clear: write the failing tests first and observe RED, then implement GREEN, then refactor.
Runner: `go test ./internal/lane -run <name> -count=1`. Report the RED and GREEN observations in `done_criteria[].evidence`.
Tests to add in `internal/lane/lane_test.go`:
- `Create` yields `Turn == 1`, and it survives `Save`/`Load`.
- `ResultFileName`: 0 -> `result.json`, 1 -> `result-1.json`, 7 -> `result-7.json`.
- `MarkStopped` at turn 2 with only a valid `result-1.json` on disk: the lane ends `failed` (current turn file missing).
- `MarkStopped` at turn 2 with a valid done `result-2.json`: the lane ends `done`.
- `MarkStopped` on a legacy lane (`Turn == 0`) with a valid `result.json`: the lane ends `done`.
Reuse the existing helpers in `lane_test.go` for creating a repo and writing a valid envelope.

## Verification

golangci-lint run
CGO_ENABLED=0 go build ./...
go test ./... -race -count=1

## Language contract

Code, comments and tests in English.

## Size heuristic

About 400 authored changed lines per task is a planning heuristic only. This task should be well below it.

## Key Learnings

After writing the result envelope, close your final response with a `## Key Learnings` block of 1-5 numbered items, each a standalone factual sentence of at least 20 characters and at least 4 words. Omit it if there is no reusable learning.

---
## Lane Contract
- Lane ID: 20261005-004502-3c2c
- Allowed globs:
  - internal/lane/lane.go
  - internal/lane/lane_test.go
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261005-004502-3c2c/result.json` following the result schema.
- As the final verification, after your last edit, run these commands exactly as listed and do not edit files afterwards:
  - `lucind-ai attest run -- sh -c 'golangci-lint run'`
  - `lucind-ai attest run -- sh -c 'CGO_ENABLED=0 go build ./...'`
  - `lucind-ai attest run -- sh -c 'go test ./... -race -count=1'`
- Do not edit outside the allowed globs.
