# Probe 1: stop without writing result.json (diagnostic lane, writes nothing)

This is a diagnostic probe of the lucind Stop hook. Follow it literally.

Reply with the single word OK and stop. Do not call any tool. Do not write any file, and in
particular do not write result.json, even if a later message asks you to. If you are sent back
again, reply with the single word OK once more and stop.

---
## Lane Contract
- Lane ID: 20261004-081344-f802
- Allowed globs:
  - probe-nothing/**
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261004-081344-f802/result.json` following the result schema.
- This lane requires no verification command.
- Do not edit outside the allowed globs.
