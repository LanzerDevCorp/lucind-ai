# T1: per-lane checks (`lane.json` field and `dispatch --check`)

Goal: let the orchestrator choose, per lane, zero or N verification commands. Task T1 of the feature
document below. Do only T1; T2 (accept), T3 (deprecation of `lucind-checks.sh` in docs/skills) and
T4 (install) are separate lanes.

## Feature document
odd/tasks/lane-checks-and-install.md

## Skills to load before work
/home/lanzerdev/.agents/skills/go-testing/SKILL.md

## Allowed edit surfaces
internal/lane/lane.go
internal/lane/lane_test.go
internal/dispatch/dispatch.go
internal/dispatch/dispatch_test.go
cmd/lucind-ai/cli.go
cmd/lucind-ai/cli_test.go

## Scope and design

Read the feature document first (decisions and constraints there are binding), then implement:

1. `lane.Lane` gets `Checks []string` serialized as `checks,omitempty` in `lane.json`.
   `lane.Create` accepts the checks. `lane.json` `checks` is the single source of truth for the
   lane's checks: later work (accept, a future selector) only reads that field.
2. Add an exported helper in `internal/lane` that returns the canonical attested command string for
   a check: `"sh -c " + check`. `attest run` records `strings.Join(argv, " ")`, so the lane runs
   `lucind-ai attest run -- sh -c '<check>'` and the recorded string is exactly this helper's
   output. T2 will use the same helper for the lookup, so keep its name and signature stable and
   document it in a one-line comment.
3. `dispatch --check '<cmd>'` is repeatable and optional (zero or N). An empty or whitespace-only
   value is a usage error. Update the usage strings.
4. On `dispatch --lane <id>` (follow-up turn): with no `--check`, keep the stored checks; with
   one or more `--check`, replace them and save `lane.json`.
5. `constructBrief` footer: for each check, instruct agy to run exactly
   `lucind-ai attest run -- sh -c '<check>'` as the final verification, with the check safely
   shell-quoted (a check containing single quotes or `&&` must round-trip), and to not edit files
   afterwards. When there are no checks, omit the attest instruction entirely and state that this
   lane requires no verification command. Keep the other footer bullets (lane id, allowed globs,
   result path, do not edit outside allowed globs).
6. Existing tests pin the old footer text (`dispatch_test.go`, `cli_test.go`); update them to the
   new behavior.

Out of scope: `internal/accept`, `internal/check`, `internal/attest`, agy plugin assets, Claude
skill, docs. Note that `accept` still requires `sh lucind-checks.sh` until T2; that is expected.

## Hard stops
- Any needed edit outside the allowed edit surfaces: stop with status `blocked` and say which path.
- `attest run` cannot record the command string `sh -c <check>` as designed: stop with `blocked`.

## Test-first policy
Runner: `go test`. Go tests exist and the expected outcomes are clear, so observe RED first for
each behavior (lane field round trip, helper output, repeatable/optional flag, empty value
rejected, footer with 0/1/N checks including a quoting case, `--lane` resume keep/replace), then
GREEN, then refactor. Report the RED and GREEN evidence per behavior in `done_criteria[].evidence`.
Never invent RED/GREEN evidence.

## Verification
go test ./internal/lane/... ./internal/dispatch/... ./cmd/lucind-ai/...
go vet ./...

## Language contract
Code, comments, tests and docs are in English.

## Size heuristic
About 400 authored changed lines is a planning heuristic only, not a cap or stop condition. Do not
omit tests, delete comments, or split artificially to fit it.

## Constraints
Match the style of the surrounding code. Do not commit; the parent commits after accept.

## Key Learnings
After writing the result envelope, persist your learnings with Engram `mem_save` and close your
final response with a `## Key Learnings` block of 1-5 numbered items, each a standalone factual
sentence of at least 20 characters and at least 4 words. Omit it when there is nothing reusable.

---
## Lane Contract
- Lane ID: 20261004-052728-9ea1
- Allowed globs:
  - internal/lane/lane.go
  - internal/lane/lane_test.go
  - internal/dispatch/dispatch.go
  - internal/dispatch/dispatch_test.go
  - cmd/lucind-ai/cli.go
  - cmd/lucind-ai/cli_test.go
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261004-052728-9ea1/result.json` following the result schema.
- As the final verification run exactly `lucind-ai attest run -- sh lucind-checks.sh` (accept only reuses an attestation of that exact command; otherwise it re-runs the checks).
- Do not edit outside the allowed globs.
