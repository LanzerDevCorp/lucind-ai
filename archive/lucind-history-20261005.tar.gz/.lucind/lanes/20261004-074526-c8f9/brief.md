# T15a: `wait` revalidates the result before reporting failed, and the Stop hook logs every payload

Context: the Stop hook spends at most `MaxRetries` (2) retries when `result.json` is missing or
invalid, then `MarkStopped` marks the lane `failed`. In practice agy's orchestrator stops while its
worker subagent is still running, the retries run out, the lane is marked `failed`, and agy later
writes a valid `done` envelope. `accept` only reads the envelope so it works, but `wait` and
`dispatch` already returned failure. We also have no data on what agy sends in the Stop payload.
Task T15a of the feature document. Do only T15a (not the "do not spend retries while a subagent
runs" logic; that comes later, driven by the logs added here).

## Feature document
odd/tasks/lane-checks-and-install.md

## Allowed edit surfaces
internal/dispatch/wait.go
internal/dispatch/wait_test.go
internal/agyhook/agyhook.go
internal/agyhook/agyhook_test.go

## Scope and design

Read the T9, T14 and T15 entries of the feature document, `waitLoop` in `internal/dispatch/wait.go`,
`Stop` and `logf` in `internal/agyhook/agyhook.go`, and `lane.MarkStopped`. Then:

1. **`waitLoop`, when `lane.json` status is `failed`.** Today it returns failed (exit 3) at once.
   Change it to read the lane's `result.json` (`result.Read` on `os.DirFS(lane dir)`) first:
   - valid envelope with `status: done`: call `lane.MarkStopped` so `lane.json` becomes `done`
     and return done (exit 0). The failed status came from retry exhaustion and was wrong.
   - valid envelope with any other status: return failed (exit 3) immediately; agy reported it.
   - missing or invalid envelope: keep polling (same `sleepFunc`/`pollInterval` seams) re-reading
     `result.json` each time, until either a valid envelope appears (apply the two rules above) or a
     grace period expires, then return failed (exit 3). The grace period starts the first time
     `waitLoop` observes `failed` with no valid envelope, is capped by the overall wait deadline
     and context, and is a package-level variable `exhaustionGrace` defaulting to 10 minutes so
     tests can shorten it. Document the trade-off in a short comment: a genuine failure is reported
     up to `exhaustionGrace` later.
   - Behavior for `done`, `timeout` and `running` stays exactly as it is.
2. **Stop hook payload logging.** Extend the hook `payload` struct with `executionNum` (int),
   `terminationReason` (string) and `error` (string) next to the existing `fullyIdle`. In `Stop`,
   right after the lane root is resolved and before the `fullyIdle` early return, write one line
   with `logf`: `stop: payload executionNum=<n> terminationReason=<s> fullyIdle=<true|false|unset> error=<quoted>`.
   Do not log `transcriptPath` or any other field. Do not change any decision logic, retry counting
   or `MaxRetries`.

Out of scope: any other file, `internal/lane`, `accept`, and any change to when retries are spent.

## Hard stops
- Any needed edit outside the allowed edit surfaces: stop with status `blocked` and say which path.

## Test-first policy
Runner: `go test`. Observe RED first, then GREEN, then refactor. Cover at least, for `wait`
(using temporary lane directories and the existing seams, no real sleeping): failed lane with a
valid `done` envelope returns done and `lane.json` becomes `done`; failed lane with a valid non-done
envelope returns failed immediately; failed lane with no envelope that later gets a valid `done`
envelope returns done; failed lane with no envelope for the whole grace returns failed after the
grace; the grace is capped by the overall deadline; `done`/`timeout` paths unchanged. For the hook
(calling `Stop` with synthetic JSON payloads): the payload line is written for `fullyIdle` true,
false and absent, with the right `fullyIdle` text; an invalid-JSON payload and an invalid lane id
write nothing and keep their current behavior; decision behavior and retry counting are unchanged
(existing tests stay green). Report RED and GREEN evidence per behavior in
`done_criteria[].evidence`. Never invent RED/GREEN evidence.

## Verification
go test ./...
go vet ./...
test -z "$(gofmt -l .)"

## Language contract
Code, comments, tests and docs are in English.

## Size heuristic
About 400 authored changed lines is a planning heuristic only, not a cap or stop condition.

## Constraints
Match the style of the surrounding code and keep every Go file `gofmt`-clean. Do not commit; the
parent commits after accept.

## Key Learnings
After writing the result envelope, persist your learnings with Engram `mem_save` and close your
final response with a `## Key Learnings` block of 1-5 numbered items, each a standalone factual
sentence of at least 20 characters and at least 4 words. Omit it when there is nothing reusable.

---
## Lane Contract
- Lane ID: 20261004-074526-c8f9
- Allowed globs:
  - internal/dispatch/wait.go
  - internal/dispatch/wait_test.go
  - internal/agyhook/agyhook.go
  - internal/agyhook/agyhook_test.go
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261004-074526-c8f9/result.json` following the result schema.
- As the final verification, after your last edit, run these commands exactly as listed and do not edit files afterwards:
  - `lucind-ai attest run -- sh -c 'go test ./...'`
  - `lucind-ai attest run -- sh -c 'go vet ./...'`
  - `lucind-ai attest run -- sh -c 'test -z "$(gofmt -l .)"'`
- Do not edit outside the allowed globs.
