# T5: dispatch must never open a lane pane outside the requested directory

Bug: `lucind-ai dispatch --cwd .` passes the relative path unresolved to
`herdr pane split --cwd` (`internal/dispatch/dispatch.go`, `SplitPane` call, and `herdr.go`). Herdr
resolves it against its own server, so the pane opens in the server's home directory, agy starts
there, and the PreToolUse hook denies every tool call because `git rev-parse --show-toplevel`
fails (exit 128). The lane then hangs silently. Evidence: lane `20261004-052728-9ea1`.

Do two things, nothing else.

## Feature document
odd/tasks/lane-checks-and-install.md

## Allowed edit surfaces
internal/dispatch/dispatch.go
internal/dispatch/dispatch_test.go
internal/dispatch/herdr.go
internal/dispatch/herdr_test.go

## Scope and design

1. Resolve `opts.Cwd` to an absolute path (`filepath.Abs`) once, at the start of `Dispatch`, before
   any use. Every later use (`lane.Create`, `SplitPane`, `waitLoop`, the output JSON `cwd`) must see
   the absolute path. The output JSON `cwd` must be absolute.
2. Fail fast after creating the pane: read the new pane's working directory with
   `herdr pane get <pane_id>` (JSON, `.result.pane.cwd`) and compare it with the expected absolute
   directory after resolving symlinks on both sides. On mismatch, close the pane you just created
   (`herdr pane close <pane_id>`), and return an error that names the expected and actual
   directories. Do this before starting agy. If `pane get` itself fails or the field is missing,
   return an error too (never continue silently). Use the existing `HerdrRunner` interface and
   follow the style of the existing helpers in `herdr.go`.

## Hard stops
- Any needed edit outside the allowed edit surfaces: stop with status `blocked` and say which path.
- If `herdr pane get` does not expose the pane cwd as described: stop with `blocked` and include
  the actual JSON you observed.

## Test-first policy
Runner: `go test`. Observe RED first, then GREEN, then refactor. Behaviors to cover with the fake
`HerdrRunner` already used in the tests: relative `Cwd` (`.`) reaches `SplitPane` as an absolute
path; output JSON `cwd` is absolute; cwd mismatch closes the pane and errors with both paths;
`pane get` failure errors; matching cwd proceeds as before. Report RED and GREEN evidence per
behavior in `done_criteria[].evidence`. Never invent RED/GREEN evidence.

## Verification
go test ./internal/dispatch/...
go vet ./...

## Language contract
Code, comments, tests and docs are in English.

## Size heuristic
About 400 authored changed lines is a planning heuristic only, not a cap or stop condition.

## Constraints
Match the style of the surrounding code. Do not commit; the parent commits after accept.

## Key Learnings
After writing the result envelope, persist your learnings with Engram `mem_save` and close your
final response with a `## Key Learnings` block of 1-5 numbered items, each a standalone factual
sentence of at least 20 characters and at least 4 words. Omit it when there is nothing reusable.

---
## Lane Contract
- Lane ID: 20261004-054348-0962
- Allowed globs:
  - internal/dispatch/dispatch.go
  - internal/dispatch/dispatch_test.go
  - internal/dispatch/herdr.go
  - internal/dispatch/herdr_test.go
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261004-054348-0962/result.json` following the result schema.
- As the final verification run exactly `lucind-ai attest run -- sh lucind-checks.sh` (accept only reuses an attestation of that exact command; otherwise it re-runs the checks).
- Do not edit outside the allowed globs.
