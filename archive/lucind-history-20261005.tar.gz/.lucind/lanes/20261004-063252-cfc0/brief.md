# FOLLOW-UP TURN: your T4 delivery is incomplete

The orchestrator reviewed your first result envelope (`status: done`) against the full brief below.
Only part of the task is in the tree. Observed state:

- Done: `lucind-roles` embed and install support in `internal/agyplugin`, and new files
  `internal/claudeplugin/*` and `plugin/claude-code/embed.go`.
- Missing: the `lucind-ai install` subcommand (`cmd/lucind-ai/install.go`, registration, usage and
  help in `cmd/lucind-ai/cli.go`, tests), the Makefile `install` change, and the doc and skill text
  updates (`README.md`, `docs/product.md`, `## Setup` in `plugin/claude-code/skills/lucind/SKILL.md`).
  `make -n install` still shows `plugin install` plus `mkdir`/`ln -sfn`.

Do now, in this turn: finish every missing item of the brief below (scope items 3, 4 and 5, and
verify items 1 and 2 against it), keeping strict TDD for the new behavior. Then write a new result
envelope where `done_criteria` has one entry per scope item (1 to 5) with evidence, and
`files_changed` lists every file you created or modified in the whole lane (including new files).
Do not report `done` while any scope item is missing. Run the final verification commands from the
Lane Contract again after your last edit.

---

# T4: one flagless `lucind-ai install` that installs everything lucind needs

Goal: today `lucind-ai plugin install` registers only the agy plugin, and the Claude skill is a
Makefile symlink. Make a single command, `lucind-ai install`, that installs exactly the same
things on any machine, so the binary is portable. It is not a configurable installer: no flags that
choose components or paths. Task T4 of the feature document. Do only T4.

## Feature document
odd/tasks/lane-checks-and-install.md

## Allowed edit surfaces
cmd/lucind-ai/cli.go
cmd/lucind-ai/cli_test.go
cmd/lucind-ai/install.go
cmd/lucind-ai/install_test.go
cmd/lucind-ai/plugin.go
cmd/lucind-ai/plugin_test.go
internal/agyplugin/agyplugin.go
internal/agyplugin/agyplugin_test.go
internal/claudeplugin/claudeplugin.go
internal/claudeplugin/claudeplugin_test.go
plugin/claude-code/embed.go
plugin/claude-code/skills/lucind/SKILL.md
Makefile
README.md
docs/product.md

## Scope and design

Read the feature document and the existing code first: `cmd/lucind-ai/plugin.go`,
`internal/agyplugin/agyplugin.go` (embedded `assets`, `Install`, `Setup`, `checkInstallOutput`),
the `Makefile` `install` target, and `plugin/claude-code/skills/lucind/SKILL.md`. Then:

1. **Claude skill, embedded.** `go:embed` cannot reach files outside its package directory, so add
   `plugin/claude-code/embed.go` (package `claudecode`) that embeds `skills`. The skill stays where
   it is; that file remains the single source of truth. Add `internal/claudeplugin` with a function
   that writes the embedded `skills/lucind/` tree into `<home>/.claude/skills/lucind` (home from
   `os.UserHomeDir()`, overridable by `HOME` in tests). It must be idempotent and replace the
   previous content. If the destination (or its parent entry `lucind`) is a symlink, such as the
   one the old Makefile created, remove the symlink and write a real directory; never write
   through it into the repository.
2. **`lucind-roles` agy plugin.** The role source is already vendored under
   `internal/agyplugin/roles/` (`plugin.json`, `agents/worker.md`); embed it with `go:embed` and
   install it with the same mechanism the `lucind` plugin uses (stage under
   `$XDG_DATA_HOME/lucind-ai/agy-plugin/lucind-roles` or the equivalent existing staging root, then
   `agy plugin install`, replacing any previous registration). Generalize `Setup`/`Install` and
   `checkInstallOutput` as needed: the `lucind` plugin must still report hooks, while `lucind-roles`
   has no hooks and agy reports its agents (for example "agents: 1 processed"); validate that it
   processed its agent and reported no errors. Do not change the content of `roles/` files.
3. **`lucind-ai install`**: new subcommand registered in `cmd/lucind-ai/cli.go` (usage text and
   help included). No component or path flags. It performs, in this order: the Claude skill, the
   `lucind` agy plugin, the `lucind-roles` agy plugin. It prints one line per component. If a step
   fails it reports which one and exits non-zero; steps before it stay installed. When `agy` is not
   on PATH, the Claude skill is still installed and the error says agy is required. Keep
   `lucind-ai plugin install` working as it does today (it may delegate to shared code).
4. **Makefile**: `install` becomes `go install ... ./cmd/lucind-ai` followed by
   `$(GOBIN)/lucind-ai install` (resolve `$GOBIN` the way the current target does); remove the
   manual `mkdir`/`ln` of the Claude skill. Keep the version ldflags unchanged.
5. **Docs and skill text**: update `README.md`, `docs/product.md` and the `## Setup` section of
   `plugin/claude-code/skills/lucind/SKILL.md` so they say `lucind-ai install` installs the Claude
   skill, the `lucind` agy plugin and the `lucind-roles` agy plugin, and that `make install` runs
   it. Do not touch other sections of the skill.

Out of scope: any change to dispatch, accept, attest, the hooks, the content of the embedded
assets, the pane lifecycle text of the skill, and removing the `plugin` subcommand.

## Hard stops
- Any needed edit outside the allowed edit surfaces: stop with status `blocked` and say which path.
- `agy plugin install` output for `lucind-roles` cannot be validated reliably: stop with `blocked`
  and include the exact output you observed.
- Never run `lucind-ai install`, `lucind-ai plugin install` or `agy plugin install` against the
  real home directory during this task. Tests must use a temporary `HOME` and fake the agy runner
  with the existing seams (for example `pluginAgy`).

## Test-first policy
Runner: `go test`. Observe RED first, then GREEN, then refactor. Cover at least: the Claude skill
is written to a temp `HOME` with the exact embedded content; running it twice is idempotent and
replaces changed content; an existing symlink at the destination is replaced by a real directory
and the symlink target is left untouched; `install` runs the three steps in order and prints one
line per component; a failing step stops the sequence, names the step, and exits non-zero; with
`agy` missing the Claude skill is still installed and the error mentions agy; the `lucind-roles`
install output validation accepts a valid agents report and rejects errors or zero agents; `plugin
install` still behaves as before. Report RED and GREEN evidence per behavior in
`done_criteria[].evidence`. Never invent RED/GREEN evidence.

## Verification
go test ./...
go vet ./...
make -n install

(`make -n` only prints the recipe; it must show `lucind-ai install` and no `ln -sfn`. Do not run
the real `make install`.)

## Language contract
Code, comments, tests and docs are in English.

## Size heuristic
About 400 authored changed lines is a planning heuristic only, not a cap or stop condition. If the
correct solution naturally exceeds it, say why and continue; never omit tests or split artificially.

## Constraints
Match the style of the surrounding code. Do not commit; the parent commits after accept.

## Key Learnings
After writing the result envelope, persist your learnings with Engram `mem_save` and close your
final response with a `## Key Learnings` block of 1-5 numbered items, each a standalone factual
sentence of at least 20 characters and at least 4 words. Omit it when there is nothing reusable.

---
## Lane Contract
- Lane ID: 20261004-063252-cfc0
- Allowed globs:
  - cmd/lucind-ai/cli.go
  - cmd/lucind-ai/cli_test.go
  - cmd/lucind-ai/install.go
  - cmd/lucind-ai/install_test.go
  - cmd/lucind-ai/plugin.go
  - cmd/lucind-ai/plugin_test.go
  - internal/agyplugin/agyplugin.go
  - internal/agyplugin/agyplugin_test.go
  - internal/claudeplugin/claudeplugin.go
  - internal/claudeplugin/claudeplugin_test.go
  - plugin/claude-code/embed.go
  - plugin/claude-code/skills/lucind/SKILL.md
  - Makefile
  - README.md
  - docs/product.md
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261004-063252-cfc0/result.json` following the result schema.
- As the final verification run exactly `lucind-ai attest run -- sh -c 'go test ./...'` and do not edit files afterwards.
- As the final verification run exactly `lucind-ai attest run -- sh -c 'go vet ./...'` and do not edit files afterwards.
- Do not edit outside the allowed globs.
