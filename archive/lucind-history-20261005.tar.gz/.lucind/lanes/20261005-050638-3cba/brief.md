# `lucind-ai install` writes the lucind dispatch block into ~/.claude/CLAUDE.md

## Skills to load before work
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-cli/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-testing/SKILL.md
/home/lanzerdev/.agents/skills/go-testing/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-error-handling/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-code-style/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-structs-interfaces/SKILL.md

## Goal

Make `lucind-ai install` (and therefore `make install`) write the lucind dispatch block into the
user's global `~/.claude/CLAUDE.md`, idempotently, so a new machine is ready after cloning the
repository and installing.

## Feature document

odd/tasks/install-claude-md.md

Read it before editing (decisions D1-D4). Do not edit it; the orchestrator owns it.

## Scope

1. The block's source of truth is `plugin/claude-code/claudemd/lucind-dispatch.md` (already
   present, do not change its content). It starts with the line `<!-- lucind:dispatch -->` and ends
   with the line `<!-- /lucind:dispatch -->`. Embed it in the binary (extend
   `plugin/claude-code/embed.go` with a new embed variable, following its style).
2. New package `internal/claudemd` with a function along the lines of
   `Install(path string, block []byte) (Outcome, error)` where `Outcome` says `created`,
   `appended`, `replaced` or `unchanged`. Rules:
   - file missing: create it (and its parent directory) with the block plus a trailing newline;
   - begin and end markers present once each, begin before end: replace the inclusive span from the
     begin-marker line to the end-marker line with the block; everything outside the span stays
     byte-identical;
   - no markers: append the block at the end, separated from existing content by exactly one blank
     line;
   - result identical to the current content: do not write, return `unchanged`;
   - malformed markers (only one present, end before begin, or either present more than once):
     return an error and write nothing;
   - when `path` is a symlink, write through to its resolved target and never replace the symlink;
   - before changing an existing file, write its previous content to `<target>.lucind-ai.bak`
     (overwriting an older backup);
   - write atomically (temporary file in the same directory, then rename) and keep the original
     file mode.
3. `cmd/lucind-ai/install.go`: after the existing steps, install the block into
   `<home>/.claude/CLAUDE.md` (home from `os.UserHomeDir`, injectable for tests the same way
   `claudeInstall` is) and print one line with the outcome and the path, for example
   `lucind dispatch block replaced in /home/u/.claude/CLAUDE.md`. Add a `--no-claude-md` flag that
   skips this step, and update `installUsage`. A failure here exits 1 with
   `lucind-ai: install claude md: <error>`.
4. Tests:
   - `internal/claudemd`: every rule above, including idempotency (install twice, second returns
     `unchanged` and the bytes are identical), content outside the markers preserved byte for byte
     (use a fixture with gentle-ai style markers and an `@RTK.md` line around the block), the
     symlink case, the backup, and each malformed-marker case writing nothing.
   - `cmd/lucind-ai/install_test.go`: the new step with a temp home, and `--no-claude-md`.
5. Docs: README install section, the Setup line in `plugin/claude-code/skills/lucind/SKILL.md`, and
   mark docs/ROADMAP.md "Next" item 6 as done (move it to "Done" following that file's style).

## Allowed edit surfaces
internal/claudemd/**
plugin/claude-code/embed.go
cmd/lucind-ai/install.go
cmd/lucind-ai/install_test.go
README.md
docs/ROADMAP.md
plugin/claude-code/skills/lucind/SKILL.md

## Hard stops
Needing to edit plugin/claude-code/claudemd/lucind-dispatch.md or any file outside the allowed edit surfaces.
Writing to the real ~/.claude/CLAUDE.md or any path outside the repository and test temp dirs (tests must use temp homes; do not run lucind-ai install yourself).
Creating git commits (the orchestrator commits).

## Verification
golangci-lint run
CGO_ENABLED=0 go build ./...
go test ./... -race -count=1

## Known environmental failures
TestLaneIDFormat can fail once in a full run (known flaky); re-run it before treating it as a failure.

## Test-first policy
When a relevant runnable deterministic test and a clear expected outcome exist, observe RED
before implementing, then GREEN, then refactor while tests stay green. Runner: `go test`. Report
the RED and GREEN observations you actually saw; never invent them.

## Language contract
Generated technical artifacts (code, comments, tests, fixtures, docs) are in English.

## Size heuristic
About 400 authored changed lines is a planning heuristic only, not a cap. If the correct, clear
solution exceeds it, say why and continue. Never minify, drop tests or split artificially.

## Key Learnings
After writing your result envelope, close your final response with a `## Key Learnings` block of
1-5 numbered items, each a standalone factual sentence of at least 20 characters and 4 words;
omit it when there is genuinely no reusable learning.

---
## Lane Contract
- Lane ID: 20261005-050638-3cba
- Allowed globs:
  - internal/claudemd/**
  - plugin/claude-code/embed.go
  - cmd/lucind-ai/install.go
  - cmd/lucind-ai/install_test.go
  - README.md
  - docs/ROADMAP.md
  - plugin/claude-code/skills/lucind/SKILL.md
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261005-050638-3cba/result-1.json` following the result schema.
- As the final verification, after your last edit, run these commands exactly as listed and do not edit files afterwards:
  - `lucind-ai attest run -- sh -c 'golangci-lint run'`
  - `lucind-ai attest run -- sh -c 'CGO_ENABLED=0 go build ./...'`
  - `lucind-ai attest run -- sh -c 'go test ./... -race -count=1'`
- Do not edit outside the allowed globs.
