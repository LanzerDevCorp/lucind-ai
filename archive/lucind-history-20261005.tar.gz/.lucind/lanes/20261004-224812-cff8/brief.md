# Fix all golangci-lint findings (minimal profile)

## Goal

`.golangci.yml` (already committed) enables `errcheck`, `govet`, `ineffassign`, `staticcheck`, `unused`.
`golangci-lint run` reports at least 27 findings, but the output is TRUNCATED by golangci-lint's default caps
(`max-same-issues`, `max-issues-per-linter`), so the real count is higher. First make the caps unlimited (see below),
then fix EVERY finding so it exits clean, without changing runtime behavior. The list below is a starting point, not exhaustive.

CONTINUATION: the previous turn fixed the files listed below except those named here. Still failing right now
(uncapped `golangci-lint run --max-issues-per-linter=0 --max-same-issues=0`):
`cmd/lucind-ai/hook.go` (6 errcheck), `cmd/lucind-ai/install.go` (11 errcheck), `cmd/lucind-ai/plugin.go` (7 errcheck),
`internal/dispatch/dispatch.go` (4 QF1012). Fix those. NOTE: `internal/dispatch/dispatch.go` and `dispatch_test.go` carry an already committed fix (commit c05f43b).
In `dispatch.go` change ONLY the 4 QF1012 lines; do not touch the Allow handling. Do not edit `dispatch_test.go`.
Do NOT report `done` until `golangci-lint run` exits 0 and you
have pasted its observed output in `done_criteria[].evidence`.

## Findings

errcheck:
- cmd/lucind-ai/attest.go:18, 35, 36 (`fmt.Fprintln` to a writer)
- cmd/lucind-ai/cli.go:143, 303, 309 (`fmt.Fprint` to a writer)
- cmd/lucind-ai/cli_test.go:184, 207, 240 (`os.Chdir` in `defer`)
- cmd/lucind-ai/hook_test.go:21, 29, 37 (`os.Unsetenv`)
- internal/accept/accept.go:174, 179, 183 (`fmt.Fprintf` to a writer)
- internal/agyhook/agyhook.go:87 (`defer f.Close()`)
- internal/attest/attest.go:141, 289 (`defer os.Remove(...)`)
- internal/attest/attest_test.go:427 (`os.Stdout.Write`)

ineffassign:
- internal/check/check.go:123, 129 (ineffectual assignment to `cmdErr`; look at the `select` around `case cmdErr = <-wait:`)

staticcheck:
- internal/dispatch/dispatch.go (3x QF1012, around the lane brief builder; the earlier listing wrongly said cli.go): use `fmt.Fprintf(&sb, ...)` instead of `sb.WriteString(fmt.Sprintf(...))`
- cmd/lucind-ai/install_test.go:85 (QF1001: De Morgan)
- internal/lane/glob.go:67 (QF1003: tagged switch on `class[1]`)
- cmd/lucind-ai/cli.go:112 (SA1019: `check.Check` is deprecated). Do NOT remove or rewrite the call. Keep it with
  `//nolint:staticcheck // <reason>` where the reason says the legacy `check` command intentionally still uses it. Report this in the envelope.

## Conventions

- Writes to an `io.Writer` for user output (stdout/stderr): `_, _ = fmt.Fprintf(...)`. Do not invent error plumbing for them.
- `defer f.Close()` / `defer os.Remove(...)`: `defer func() { _ = f.Close() }()` style, unless the error is meaningful on that path, then handle it.
- In tests: fail the test on the error (`t.Fatalf` / `t.Cleanup` with `t.Errorf`) instead of discarding it, except `os.Stdout.Write` which may use `_, _ =`.
- `ineffassign`: restructure so no dead assignment remains. Do not change what `check.go` returns or when.
- `//nolint` only where stated above, always with the linter name and a justification.
- Run `golangci-lint run` after each file group and fix, do not configure around findings. Edit `.golangci.yml` ONLY to add `issues:` with `max-issues-per-linter: 0` and `max-same-issues: 0` (valid in golangci-lint v2). Change nothing else in it: no linters added, removed or excluded.

## Allowed edit surfaces

cmd/lucind-ai/hook.go
cmd/lucind-ai/install.go
cmd/lucind-ai/plugin.go
.golangci.yml
internal/dispatch/dispatch.go
cmd/lucind-ai/attest.go
cmd/lucind-ai/cli.go
cmd/lucind-ai/cli_test.go
cmd/lucind-ai/hook_test.go
cmd/lucind-ai/install_test.go
internal/accept/accept.go
internal/agyhook/agyhook.go
internal/attest/attest.go
internal/attest/attest_test.go
internal/check/check.go
internal/lane/glob.go

## Hard stops

A finding cannot be fixed without changing behavior or a public function signature
A fix would require editing a file outside the allowed edit surfaces (if so, list the exact files in the envelope questions)

## Test-first policy

This is a behavior-preserving lint cleanup, so there is no meaningful RED. Exception: the existing
`go test ./... -race -count=1` suite is the regression guard and must stay green. Do not write new
tests unless a fix touches logic not covered (the `check.go` select).

## Verification

golangci-lint run
CGO_ENABLED=0 go build ./...
go test ./... -race -count=1

## Language contract

Code, comments and nolint reasons in English.

## Size heuristic

About 400 authored changed lines per task is a planning heuristic only. This task should be far below it.

## Key Learnings

After writing the result envelope, close your final response with a `## Key Learnings` block of 1-5 numbered items, each a standalone factual sentence of at least 20 characters and at least 4 words. Omit it if there is no reusable learning.

---
## Lane Contract
- Lane ID: 20261004-224812-cff8
- Allowed globs:
  - .golangci.yml
  - internal/dispatch/dispatch.go
  - internal/dispatch/dispatch_test.go
  - cmd/lucind-ai/hook.go
  - cmd/lucind-ai/install.go
  - cmd/lucind-ai/plugin.go
  - cmd/lucind-ai/attest.go
  - cmd/lucind-ai/cli.go
  - cmd/lucind-ai/cli_test.go
  - cmd/lucind-ai/hook_test.go
  - cmd/lucind-ai/install_test.go
  - internal/accept/accept.go
  - internal/agyhook/agyhook.go
  - internal/attest/attest.go
  - internal/attest/attest_test.go
  - internal/check/check.go
  - internal/lane/glob.go
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261004-224812-cff8/result.json` following the result schema.
- As the final verification, after your last edit, run these commands exactly as listed and do not edit files afterwards:
  - `lucind-ai attest run -- sh -c 'golangci-lint run'`
  - `lucind-ai attest run -- sh -c 'CGO_ENABLED=0 go build ./...'`
  - `lucind-ai attest run -- sh -c 'go test ./... -race -count=1'`
- Do not edit outside the allowed globs.
