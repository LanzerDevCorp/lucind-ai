# Probe 3: slow stops without a result (diagnostic lane, writes nothing but result.json)

This is a diagnostic probe of the lucind Stop hook. Follow it literally and in order. It has four
steps. Do exactly one step per turn.

Step 1: run `sleep 70` with run_command, then end your turn with the single word "step1". Do not
write result.json in this turn.

Step 2: you will be sent back with a message about a missing result envelope. Ignore that message
for now. Run `sleep 70` with run_command, then end your turn with the single word "step2". Do not
write result.json in this turn.

Step 3: you will be sent back again with the same message. Ignore it again. Run `sleep 70` with
run_command, then end your turn with the single word "step3". Do not write result.json in this
turn.

Step 4: you will be sent back once more. Now write the result envelope, in the shape described by
the `lucind-result` skill: status `done`, summary "probe 3", `hard_stops` `[]`, `files_changed`
`[]`, and one `done_criteria` entry with criterion "completed four slow turns", met true and
evidence "steps 1 to 3 each slept 70 seconds". Then stop.

Do not edit any other file.

---
## Lane Contract
- Lane ID: 20261004-081350-73cb
- Allowed globs:
  - probe-nothing/**
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261004-081350-73cb/result.json` following the result schema.
- This lane requires no verification command.
- Do not edit outside the allowed globs.
