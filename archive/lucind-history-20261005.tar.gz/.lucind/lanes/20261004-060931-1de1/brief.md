# T3: deprecate `lucind-checks.sh` in the lane flow, docs and skills

Goal: since T1/T2, the checks of a lane are chosen by the orchestrator with `dispatch --check` and
stored in `lane.json`; `accept` verifies exactly those. `sh lucind-checks.sh` is no longer the
lane's verification command, not even a default. Make every user-facing text say so. Task T3 of the
feature document. Do only T3.

## Feature document
odd/tasks/lane-checks-and-install.md

## Allowed edit surfaces
internal/agyplugin/assets/rules/lucind-lane.md
internal/agyplugin/assets/skills/lucind-result/SKILL.md
plugin/claude-code/skills/lucind/SKILL.md
docs/product.md
docs/attestation.md
README.md
internal/check/check.go
cmd/lucind-ai/cli.go
cmd/lucind-ai/cli_test.go

## Scope and design

Read the feature document first (decisions there are binding), and read `internal/dispatch` and
`internal/accept` to describe the real behavior accurately. Then:

1. Agy plugin assets (`lucind-lane.md`, `lucind-result/SKILL.md`): replace the hardcoded
   `lucind-ai attest run -- sh lucind-checks.sh` instruction. Agy must run exactly the
   `lucind-ai attest run -- sh -c '<check>'` commands listed in the brief's `## Lane Contract`, and
   nothing when the contract lists none. Keep the rest of those files (envelope, Key Learnings)
   unchanged.
2. Claude skill `plugin/claude-code/skills/lucind/SKILL.md`: update the three places that name
   `lucind-checks.sh` (the `accept` description, the footer description, and the `## Verification`
   section). Describe `--check '<cmd>'` as optional and repeatable: the orchestrator picks the
   checks that fit the change (a lint, one test type, e2e, or the whole suite); with none, `accept`
   requires no attestation. `accept` reuses a valid attestation per check on the final tree and
   runs only the missing ones. Add `--check` to the lane command synopsis. Do not touch the pane
   lifecycle or `--cwd` text; that is another task.
3. Docs `docs/product.md`, `docs/attestation.md`, `README.md`: remove `lucind-checks.sh` as the
   canonical lane command. In `docs/attestation.md` the attested command for a check is
   `sh -c <check>` (`lane.CheckCommand`); explain per-check matching and the zero-checks case.
   Mention `check` only as deprecated.
4. Deprecate the `check` subcommand without removing it: say so in its usage/help text in
   `cmd/lucind-ai/cli.go` (and update the tests that pin that text in `cli_test.go`), and add a
   `Deprecated:` doc comment on `Check` in `internal/check/check.go`. Do not change any behavior,
   the `Command: lucind-checks.sh` log line, or `internal/check/check_test.go`.

Out of scope: any Go behavior change, `internal/dispatch`, `internal/accept`, `internal/attest`,
the pane lifecycle text in the Claude skill, `lucind-roles`.

## Hard stops
- Any needed edit outside the allowed edit surfaces: stop with status `blocked` and say which path.
- A statement you are about to write contradicts the actual behavior of `dispatch` or `accept`:
  stop with `blocked` and explain the mismatch instead of documenting it.

## Test-first policy
These are mostly passive documentation edits, so there is no meaningful RED for them: say so as the
exception and use the structural checks below. The `check` help text is a behavior with a pinned
test: for that one, observe RED (update the test first), then GREEN. Never invent RED/GREEN
evidence.

## Verification
go test ./...
go vet ./...

After editing, `rg -n "lucind-checks" README.md docs plugin internal/agyplugin` must only match
text that explicitly describes the deprecated `check` subcommand. Report the exact matches left.

## Language contract
Code, comments, tests and docs are in English.

## Size heuristic
About 400 authored changed lines is a planning heuristic only, not a cap or stop condition.

## Constraints
Match the tone and format of the surrounding docs. Do not commit; the parent commits after accept.

## Key Learnings
After writing the result envelope, persist your learnings with Engram `mem_save` and close your
final response with a `## Key Learnings` block of 1-5 numbered items, each a standalone factual
sentence of at least 20 characters and at least 4 words. Omit it when there is nothing reusable.

---
## Lane Contract
- Lane ID: 20261004-060931-1de1
- Allowed globs:
  - internal/agyplugin/assets/rules/lucind-lane.md
  - internal/agyplugin/assets/skills/lucind-result/SKILL.md
  - plugin/claude-code/skills/lucind/SKILL.md
  - docs/product.md
  - docs/attestation.md
  - README.md
  - internal/check/check.go
  - cmd/lucind-ai/cli.go
  - cmd/lucind-ai/cli_test.go
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261004-060931-1de1/result.json` following the result schema.
- As the final verification run exactly `lucind-ai attest run -- sh -c 'go test ./...'` and do not edit files afterwards.
- As the final verification run exactly `lucind-ai attest run -- sh -c 'go vet ./...'` and do not edit files afterwards.
- Do not edit outside the allowed globs.
