# T4: hook and accept use the per-turn result file; log the raw Stop payload

## Goal

T2 added `Lane.Turn`, `lane.ResultFileName(turn)`, `lane.ResultFilePath(root, l)`. T3 made `dispatch` and `wait` use them
(agy is now told to write `result-<turn>.json`). This task finishes the migration in the agy hook and in `accept`, so a result
written by any other turn can never close, pass or be accepted as the current one. It also removes the transitional code.

## Feature document

Read `odd/tasks/turn-bound-results.md` before editing (objective, decisions, acceptance criteria).

## Required behavior

In `internal/agyhook/agyhook.go`:

- PreToolUse: the only `.lucind/` file a file-write tool may touch outside the lane's allowed globs is the **current turn's** result
  file, `lane.ResultFilePath(root, l)` (today it allows `lane.ResultPath(root, laneID)`). A write to another turn's result file
  (for example `result-1.json` while the lane is at turn 2) falls through to the existing deny.
- Stop: read the current turn file (`lane.ResultFileName(l.Turn)` from the already loaded lane) instead of the literal `result.json`;
  the retry message names the current turn file path. A valid file of another turn counts as "missing".
- Stop: log the raw payload. Right after reading stdin, write one extra `hook.log` line, `stop: raw payload <json>`, with the JSON
  compacted onto one line and truncated to 4096 bytes (valid UTF-8, add a marker when truncated). Reason: we only decode
  six fields and need to see whether agy sends a turn or conversation identifier. Do not change any decision based on it.

In `internal/accept/accept.go`:

- Validate the current turn's result file (`lane.ResultFilePath` / `lane.ResultFileName(l.Turn)`) instead of `result.json`.
  Update the reason strings to name the actual file. A lane at turn 2 with only a valid `result-1.json` must be refused.

In `internal/lane/lane.go`:

- Remove the transitional fallback in `MarkStopped` (the turn-1 read of `result.json`). A lane at turn 1 with only `result.json`
  must now end `failed`. Legacy lanes (`Turn == 0`) keep using `result.json` through `ResultFileName(0)`.
- Remove the legacy `ResultPath(root, id)` once no caller is left. Update its tests to use `ResultFilePath`.

Do not touch `internal/dispatch`, the result schema or the lane ID format.

## Skills to load before work

/home/lanzerdev/git_root/lucind-ai/.claude/skills/golang-testing/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.claude/skills/golang-error-handling/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.claude/skills/golang-naming/SKILL.md

## Allowed edit surfaces

internal/agyhook/agyhook.go
internal/agyhook/agyhook_test.go
internal/accept/accept.go
internal/accept/accept_test.go
internal/lane/lane.go
internal/lane/lane_test.go
cmd/lucind-ai/cli_test.go

## Hard stops

An exported function signature used outside the allowed edit surfaces would have to change
A change is needed outside the allowed edit surfaces
Any git write command would be needed (add, commit, stash, checkout, reset, rebase): never run them, the orchestrator commits

## Test-first policy

Go tests exist and expected outcomes are clear: write the failing tests first and observe RED, then implement GREEN, then refactor.
Runner: `go test ./internal/agyhook ./internal/accept ./internal/lane -run <name> -count=1`. Report RED and GREEN observations in
`done_criteria[].evidence`. Tests to add or update:
- PreToolUse at turn 2: write to `result-2.json` allowed; write to `result-1.json` and to `result.json` denied.
- Stop at turn 2 with only a valid done `result-1.json`: treated as missing (retry message names `result-2.json`), lane stays running.
- Stop at turn 2 with a valid done `result-2.json`: lane marked done.
- Stop on a legacy lane (`Turn == 0`) with a valid `result.json`: marked done.
- Stop logs `stop: raw payload` with a single-line payload; a payload over 4096 bytes is truncated with the marker.
- `accept` at turn 2: refused with only `result-1.json`; accepted with a valid done `result-2.json`; legacy lane accepted with `result.json`.
- `MarkStopped` at turn 1 with only `result.json`: lane ends failed (fallback removed).
Existing tests that write `result.json` for lanes made by `lane.Create` (now `Turn == 1`) must write the turn file through
`lane.ResultFilePath`; do not weaken their assertions.

## Verification

golangci-lint run
CGO_ENABLED=0 go build ./...
go test ./... -race -count=1

## Language contract

Code, comments and tests in English.

## Size heuristic

About 400 authored changed lines per task is a planning heuristic only. If the correct solution exceeds it, say why and continue.

## Key Learnings

After writing the result envelope, close your final response with a `## Key Learnings` block of 1-5 numbered items, each a standalone factual sentence of at least 20 characters and at least 4 words. Omit it if there is no reusable learning.

---
## Lane Contract
- Lane ID: 20261005-010459-1a98
- Allowed globs:
  - internal/agyhook/agyhook.go
  - internal/agyhook/agyhook_test.go
  - internal/accept/accept.go
  - internal/accept/accept_test.go
  - internal/lane/lane.go
  - internal/lane/lane_test.go
  - cmd/lucind-ai/cli_test.go
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261005-010459-1a98/result.json` following the result schema.
- As the final verification, after your last edit, run these commands exactly as listed and do not edit files afterwards:
  - `lucind-ai attest run -- sh -c 'golangci-lint run'`
  - `lucind-ai attest run -- sh -c 'CGO_ENABLED=0 go build ./...'`
  - `lucind-ai attest run -- sh -c 'go test ./... -race -count=1'`
- Do not edit outside the allowed globs.
