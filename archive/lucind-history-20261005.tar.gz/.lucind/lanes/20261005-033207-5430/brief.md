# T1: Jev skill selector package and `lucind-ai skills select`

## Goal

Add a new package `internal/skillselect` that asks Jev (TypeSafe System One) which skills from
the project skill registry a coding subagent must read before implementing a brief, plus a CLI
subcommand `lucind-ai skills select` that prints the decision as JSON. Dispatch integration is
NOT part of this task (it is T2).

## Feature document

odd/tasks/jev-skill-selector.md

Read it before editing (decisions D1-D7). Do not edit it; the orchestrator owns it.

## Jev API facts (from https://docs.typesafe.ai/api.md and /primitives/noul.md)

- `POST https://api.typesafe.ai/v1/systemone`, headers `Authorization: Bearer <key>`,
  `Content-Type: application/json`.
- Request: `{"model": "jev-latest", "state": <string|object>, "questions": {"<id>": {"type": "noul", "instructions": <string|object|array>, "criteria": {"true": "...", "false": "..."}}}}`.
- Response: `{"model": "jev-1.13.0", "answers": {"<id>": {"type": "noul", "noul": 0.99}}, "usage": {"input_tokens": 360, "output_tokens": 39}}`.
  `noul` is the probability of yes, 0..1.
- Errors: 401 bad key, 422 validation, 429 rate limit, 529 overloaded.
- Question ids are NOT sent to the model meaningfully; every question must be self-contained.
- Nouls in one request are evaluated in parallel.

## Scope

1. `internal/skillselect/registry.go`: `type Skill struct { Name, Description, Scope, Path string }`
   and `ParseRegistry(r io.Reader) ([]Skill, error)`. The registry (`.atl/skill-registry.md`,
   produced by `gentle-ai skill-registry refresh`) has a Markdown table under `## Skills` with
   header `| Skill | Trigger / description | Scope | Path |`; `Skill` and `Path` cells are wrapped
   in backticks (strip them). Descriptions may contain backticks and `→`; they do not contain `|`.
   Ignore every other table/section. Error when the table is missing or a row is malformed; an
   empty table returns an empty slice. Keep a small fixture in `internal/skillselect/testdata/`.
2. `internal/skillselect/jev.go`: plain `net/http` client (no SDK). `type Client struct` with
   unexported base URL, key, and `*http.Client`; `NewClient(key string, opts ...)` or similar,
   with a way for tests to point it at an `httptest` server. Hardening (this mirrors the deleted
   `internal/router/jev.go`, viewable with `git show c8897c2^:internal/router/jev.go`):
   - require https, except loopback hosts (127.0.0.1, ::1, localhost) for tests;
   - never follow redirects (`CheckRedirect` returns `http.ErrUseLastResponse`), so the bearer key
     only reaches the validated URL;
   - cap the response body at 1 MiB;
   - no retries; a default timeout of 30 s;
   - typed errors for: missing key, non-2xx status (keep the status code, and a short body excerpt
     without the key), malformed JSON, and an answer missing for a requested question;
   - the key never appears in any error string or log.
   `KeyFromEnv()` reads `TYPESAFE_API_KEY` only (no fallbacks, never read from files).
3. `internal/skillselect/select.go`:
   - `type Input struct { Brief string; Allow []string }`.
   - `type Decision struct { Name, Path string; Probability float64; Selected bool }` with JSON tags
     `name`, `path`, `probability`, `selected`.
   - `type Result struct { Model string; Threshold float64; Decisions []Decision; Usage Usage }`
     with JSON tags `model`, `threshold`, `decisions`, `usage` (`input_tokens`, `output_tokens`).
   - `const DefaultThreshold = 0.7`.
   - `Select(ctx, client, skills []Skill, in Input, threshold float64) (Result, error)`: one request
     with one Noul per skill (ids like `skill_000`, mapped back by index). Decisions sorted by
     probability descending, ties by name. `Selected = Probability >= threshold`. Zero skills
     returns an empty result without a network call.
   - State is a JSON object: `task_brief` (the brief), `allowed_edit_surfaces` (the allow globs),
     `file_extensions` (sorted unique extensions derived from the allow globs, for example
     `.go`, `.md`; omit globs without one).
   - Each Noul's `instructions` is an object along these lines (wording may be refined, keep the
     meaning):
     - `executor`: "A coding subagent will implement `task_brief`, editing only files matching
       `allowed_edit_surfaces`. It writes code, tests and docs. It cannot open pull requests,
       create issues, orchestrate or delegate to other agents, review other work, or talk to the
       user."
     - `question`: "Must this subagent read the skill below before it starts changing files?"
     - `skill`: `{ "name": ..., "description": ... }`.
   - `criteria`: `true`: "The skill's guidance directly shapes code, tests or documentation the
     subagent will write for this task." `false`: "The skill is unrelated to the task, only covers
     orchestration, delegation, pull requests, issues, reviews or user interaction, or merely
     shares the task's topic without guiding the subagent's edits."
   - `Section(decisions []Decision) string`: renders `## Skills to load before work` followed by one
     selected path per line (in decision order), ending with a newline; returns "" when none is
     selected.
4. CLI: in `cmd/lucind-ai`, add `skills select` (new file `cmd/lucind-ai/skills.go` plus wiring in
   `cli.go`'s command switch and usage text). Flags: `--brief <file|->` (required, `-` = stdin),
   `--allow <glob>` (repeatable), `--cwd` (default `.`), `--registry` (default
   `<repo-root>/.atl/skill-registry.md`, repo root resolved like the other commands via
   `attest.RepoToplevel`), `--threshold` (default 0.7, must be in (0,1]). Prints the `Result` as
   indented JSON on stdout. Exit 0 on success, 1 on any error with the error on stderr. Follow the
   existing flag/exit style in `cli.go` (`flag.NewFlagSet(..., flag.ContinueOnError)`).
5. Tests:
   - registry parser: real-shaped fixture, missing table, malformed row, backtick stripping.
   - client/selector against `httptest.NewServer` (loopback): request shape (model, one Noul per
     skill, state fields, bearer header), probability mapping and sorting, threshold, missing
     answer, non-2xx with typed error, oversized body, a redirecting server is not followed (and
     the key never reaches the redirect target), non-https non-loopback URL rejected, key absent
     from error strings.
   - `Section` rendering.
   - CLI test in `cmd/lucind-ai` for flag validation (missing brief, bad threshold, missing
     registry) without network.
   - An opt-in live test that only runs when `TYPESAFE_LIVE_TEST=1` and `TYPESAFE_API_KEY` are set
     (skip otherwise), calling the real API with a two-skill registry.
6. Docs: add `docs/skill-selection.md` describing the subcommand, the env var, the registry
   source, the threshold and that it is experimental. Add the `skills select` line to the README
   command list if the README has one.

## Allowed edit surfaces
internal/skillselect/**
cmd/lucind-ai/skills.go
cmd/lucind-ai/skills_test.go
cmd/lucind-ai/cli.go
cmd/lucind-ai/cli_test.go
docs/skill-selection.md
README.md

## Skills to load before work
/home/lanzerdev/git_root/lucind-ai/.claude/skills/golang-cli/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.claude/skills/golang-error-handling/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.claude/skills/golang-testing/SKILL.md

## Hard stops
Making a real network call to api.typesafe.ai outside the opt-in live test.
Needing to edit a file outside the allowed edit surfaces.
Adding a third-party Go dependency.

## Verification
golangci-lint run
CGO_ENABLED=0 go build ./...
go test ./... -race -count=1

## Known environmental failures
TestLaneIDFormat can fail once in a full run (known flaky); re-run it before treating it as a failure.

## Test-first policy
When a relevant runnable deterministic test and a clear expected outcome exist, observe RED
before implementing, then GREEN, then refactor while tests stay green. Runner: `go test`. Report
the RED and GREEN observations you actually saw; never invent them.

## Language contract
Generated technical artifacts (code, comments, tests, fixtures, docs) are in English.

## Size heuristic
About 400 authored changed lines is a planning heuristic only, not a cap. If the correct, clear
solution exceeds it, say why and continue. Never minify, drop tests or split artificially.

## Key Learnings
After writing your result envelope, close your final response with a `## Key Learnings` block of
1-5 numbered items, each a standalone factual sentence of at least 20 characters and 4 words;
omit it when there is genuinely no reusable learning.

## Follow-up corrections (turn 2)

Turn 1 is mostly accepted. Fix only these, keeping everything else as is, and add tests for each:

1. `internal/skillselect/select.go` `rawAnswer`: the documented Noul answer field is only `noul`.
   Remove the `probability`, `confidence` and `value` fallbacks (a Choice/Score `confidence` is not
   a yes-probability). A missing `noul`, an answer whose `type` is not `noul`, a NaN, or a value
   outside [0, 1] must return a typed error naming the question id.
2. `cmd/lucind-ai/skills.go`: `--threshold NaN` currently passes the `(0, 1]` check. Reject NaN
   (use `math.IsNaN`) with the same error message.

---
## Lane Contract
- Lane ID: 20261005-033207-5430
- Allowed globs:
  - internal/skillselect/**
  - cmd/lucind-ai/skills.go
  - cmd/lucind-ai/skills_test.go
  - cmd/lucind-ai/cli.go
  - cmd/lucind-ai/cli_test.go
  - docs/skill-selection.md
  - README.md
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261005-033207-5430/result-2.json` following the result schema.
- As the final verification, after your last edit, run these commands exactly as listed and do not edit files afterwards:
  - `lucind-ai attest run -- sh -c 'golangci-lint run'`
  - `lucind-ai attest run -- sh -c 'CGO_ENABLED=0 go build ./...'`
  - `lucind-ai attest run -- sh -c 'go test ./... -race -count=1'`
- Do not edit outside the allowed globs.
