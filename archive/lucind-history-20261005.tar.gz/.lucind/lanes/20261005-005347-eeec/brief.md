# T3: dispatch and wait use the per-turn result file

## Goal

T2 added `Lane.Turn`, `lane.ResultFileName(turn)` and `lane.ResultFilePath(root, l)` (result-<turn>.json; `result.json` for legacy turn 0).
This task makes `dispatch` and `wait` use them, so a result written by any other turn can never close or recover the current one.
`internal/agyhook` and `internal/accept` are NOT part of this task (T4). The whole repo must keep compiling and passing.

## Feature document

Read `odd/tasks/turn-bound-results.md` before editing (objective, decisions, acceptance criteria).

## Required behavior

In `internal/dispatch/dispatch.go`:

- The result path given to the agent (brief footer) and `Output.ResultPath` is the absolute path of the **current turn file**
  (`lane.ResultFilePath`), for new lanes (`result-1.json`) and for continuations.
- Continuation (`--lane`): increment `Turn` and persist it together with the existing status/retries reset, before writing the brief.
  Do NOT rename the previous result for lanes that already have `Turn >= 1`: previous turn files stay as history.
  For a **legacy** lane (loaded `Turn == 0`) keep today's rename of `result.json` to `result.prev.json`, then the turn becomes 1,
  so the stale legacy file can never be read as turn 1.
- Everything else (pane handling, prompt, `--allow`/`--check` persistence) stays as is.

In `internal/dispatch/wait.go`:

- Use the current turn file (`lane.ResultFilePath` of the lane loaded on each poll) for every result read and for `Output.ResultPath`.
- `Status == done` must be **revalidated**: read the current turn file; return done (exit 0) only if it is valid with `status: done`.
  If the lane says done but the current turn file is missing, invalid or not done, return failed (exit 3) instead of trusting the status.
- The failed-to-done recovery (valid done envelope found for a failed lane) must also use only the current turn file.
- Keep the existing grace window and timeout behavior for the rest.

Do not touch `internal/lane`, `internal/agyhook`, `internal/accept` or the result schema.

## Skills to load before work

/home/lanzerdev/git_root/lucind-ai/.claude/skills/golang-testing/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.claude/skills/golang-error-handling/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.claude/skills/golang-naming/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.claude/skills/golang-context/SKILL.md

## Allowed edit surfaces

internal/dispatch/dispatch.go
internal/dispatch/wait.go
internal/dispatch/dispatch_test.go
internal/dispatch/wait_test.go
cmd/lucind-ai/cli_test.go

## Hard stops

An exported function signature used outside internal/dispatch would have to change
A change is needed outside the allowed edit surfaces

## Test-first policy

Go tests exist and expected outcomes are clear: write the failing tests first and observe RED, then implement GREEN, then refactor.
Runner: `go test ./internal/dispatch -run <name> -count=1`. Report RED and GREEN observations in `done_criteria[].evidence`.
Tests to add or update:
- New lane: brief footer and `Output.ResultPath` end with `result-1.json`.
- Continuation of a turn-1 lane: `Turn` becomes 2 in `lane.json`, the footer and `Output.ResultPath` end with `result-2.json`,
  `result-1.json` is untouched and no `result.prev.json` is created.
- Continuation of a legacy lane (`Turn == 0`, with a `result.json`): `Turn` becomes 1 and the old file is renamed to `result.prev.json`.
- `wait`: lane done at turn 2 with only a valid `result-1.json` is reported failed (exit 3), not done.
- `wait`: lane done at turn 2 with a valid done `result-2.json` is reported done (exit 0).
- `wait`: failed lane at turn 2 with only `result-1.json` does not recover to done; with a valid done `result-2.json` it recovers.
Existing tests that write `result.json` for lanes created through `lane.Create` (now `Turn == 1`) must be updated to write the
turn file through `lane.ResultFilePath`; do not weaken their assertions.

## Verification

golangci-lint run
CGO_ENABLED=0 go build ./...
go test ./... -race -count=1

## Language contract

Code, comments and tests in English.

## Size heuristic

About 400 authored changed lines per task is a planning heuristic only. If the correct solution exceeds it, say why and continue.

## Key Learnings

After writing the result envelope, close your final response with a `## Key Learnings` block of 1-5 numbered items, each a standalone factual sentence of at least 20 characters and at least 4 words. Omit it if there is no reusable learning.

---
## Lane Contract
- Lane ID: 20261005-005347-eeec
- Allowed globs:
  - internal/dispatch/dispatch.go
  - internal/dispatch/wait.go
  - internal/dispatch/dispatch_test.go
  - internal/dispatch/wait_test.go
  - cmd/lucind-ai/cli_test.go
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261005-005347-eeec/result.json` following the result schema.
- As the final verification, after your last edit, run these commands exactly as listed and do not edit files afterwards:
  - `lucind-ai attest run -- sh -c 'golangci-lint run'`
  - `lucind-ai attest run -- sh -c 'CGO_ENABLED=0 go build ./...'`
  - `lucind-ai attest run -- sh -c 'go test ./... -race -count=1'`
- Do not edit outside the allowed globs.
