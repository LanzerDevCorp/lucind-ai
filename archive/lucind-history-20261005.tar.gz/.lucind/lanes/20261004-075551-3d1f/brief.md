# Probe 2: end your turn while a subagent is still running (diagnostic lane, writes nothing but result.json)

This is a diagnostic probe of the lucind Stop hook. Follow it literally and in order.

1. Invoke the custom subagent named `worker` (invoke_subagent) with this exact task: "Run the
   shell command `sleep 90` with run_command, wait for it to finish, then report the single word
   done."
2. Immediately after invoking it, end your turn with one short sentence saying you are waiting for
   the worker. Do not poll the worker, do not call manage_subagents, and do not wait for it inside
   this turn.
3. When the worker later reports back to you, write the result envelope with this content, in the
   shape described by the `lucind-result` skill: status `done`, summary "probe 2", `hard_stops`
   `[]`, `files_changed` `[]`, and one `done_criteria` entry with criterion "worker slept 90
   seconds", met true and evidence "worker reported done". Then stop.

Do not edit any other file.

---
## Lane Contract
- Lane ID: 20261004-075551-3d1f
- Allowed globs:
  - probe-nothing/**
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261004-075551-3d1f/result.json` following the result schema.
- This lane requires no verification command.
- Do not edit outside the allowed globs.
