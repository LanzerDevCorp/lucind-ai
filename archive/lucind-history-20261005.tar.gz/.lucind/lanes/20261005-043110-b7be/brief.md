# Lane completion from the main agy conversation, and `dispatch --lane` reusing `--allow`

## Skills to load before work
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-cli/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-testing/SKILL.md
/home/lanzerdev/.agents/skills/go-testing/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-code-style/SKILL.md
/home/lanzerdev/git_root/lucind-ai/.agents/skills/golang-error-handling/SKILL.md

## Goal

Two independent fixes in lucind-ai:

1. T1: the agy Stop hook must decide lane completion only from the lane's main agy conversation
   once it is fully idle, and must ignore Stops from agy's worker subagents.
2. T2: `lucind-ai dispatch --lane <id>` must work without `--allow`, reusing the lane's stored
   globs.

## Feature document

odd/tasks/lane-stop-main-conversation.md

Read it before editing: it holds the root cause, the evidence and decisions D1-D4. Do not edit it;
the orchestrator owns it.

## Root cause and evidence

agy is an orchestrator: the main conversation receives the brief and spawns worker subagents.
The Stop hook (`internal/agyhook/agyhook.go`, `Stop`, around line 205) fires for every agy
conversation and treats all of them alike. Evidence in
`.lucind/lanes/20261005-035100-7fce/hook.log` (raw Stop payloads are logged there):

- main conversation `0c13b5df-...` sent `fullyIdle=false` on every Stop while its workers ran;
- worker conversations `ed047531-...` and `ba81bfb2-...` sent `fullyIdle=true` when each worker
  finished;
- the hook injected the "write the envelope" retry nudge into those workers and finally marked the
  lane `done` (`04:02:45Z stop: lane marked done`) while the main conversation still had workers
  running. In another lane a nudged worker copied the previous turn's envelope into the current
  turn's result file.

Payload fields seen: `conversationId`, `transcriptPath`, `artifactDirectoryPath`, `executionNum`,
`fullyIdle`, `terminationReason`, `modelName`, `error`. There is no turn id or parent id field.
docs/ROADMAP.md (item 3, "Stops from other conversations") notes that after a continuation the main
decisions came from a different `conversationId`, so `conversationId` alone does not identify the
main conversation, and suggests looking at `transcriptPath`.

## Scope

### T1. Stop hook decides only from the main conversation

1. Investigate first (read-only): open the transcripts referenced by `transcriptPath` in that
   `hook.log` (under `~/.gemini/antigravity-cli/brain/<conversationId>/`) and in other lanes'
   `hook.log` files under `.lucind/lanes/*/`, and find a reliable marker that tells the lane's main
   conversation apart from worker conversations. The likely marker is that the main conversation's
   first user message is the dispatch prompt that points at the lane's `brief.md`
   (`Read and follow <abs path>/.lucind/lanes/<id>/brief.md`), while workers get prompts written by
   the main agent. Confirm or refute with real transcripts and report what you found in the
   envelope. If no reliable marker exists, stop and report (see hard stops).
2. Classify each Stop as `main` or `worker` using that marker. Cache the classification per
   `conversationId` in the lane directory if it keeps the hook cheap, but a continuation turn must
   re-identify its main conversation (the main conversation may change between turns).
3. Decision rules:
   - worker Stop: allow the stop, no nudge, no retry counted, no status change; log
     `stop: ignored worker conversation <id>`;
   - main Stop with `fullyIdle=false`: allow the stop, no nudge, no retry counted, no status
     change; log `stop: main conversation not fully idle`;
   - main Stop with `fullyIdle=true`: today's logic (valid current-turn envelope marks done;
     otherwise the retry nudge, then failed when the budget is spent);
   - transcript unreadable or marker unknown: fall back to `fullyIdle` alone (a `fullyIdle=false`
     Stop never decides) and log the fallback.
4. Keep the per-turn result file rules and the retry budget/reset logic as they are.
5. Tests in `internal/agyhook` with fake payloads and fake transcript files covering every rule
   above, including a continuation turn whose main conversation id differs from turn 1.
6. Docs: update docs/ROADMAP.md item 3 to record the fix and the marker found; update the known
   limit note in `plugin/claude-code/skills/lucind/SKILL.md` (the "Review before accept" bullet
   mentions a Stop from a previous turn being indistinguishable) to reflect the new behavior.

### T2. `dispatch --lane` reuses stored `--allow`

`cmd/lucind-ai/cli.go:338` rejects a dispatch without `--allow` even for `--lane`, although
`internal/dispatch/dispatch.go` already keeps the lane's globs when `opts.Allow` is empty. Make
`--allow` required only for a new lane; with `--lane` and no `--allow`, the stored globs apply;
with `--allow`, they replace the stored ones (today's behavior). Add CLI tests for both cases and
update the dispatch usage text and the lucind skill's "Lane" section.

## Allowed edit surfaces
internal/agyhook/**
internal/lane/lane.go
internal/lane/lane_test.go
internal/dispatch/dispatch.go
internal/dispatch/dispatch_test.go
cmd/lucind-ai/cli.go
cmd/lucind-ai/cli_test.go
cmd/lucind-ai/hook.go
cmd/lucind-ai/hook_test.go
docs/ROADMAP.md
plugin/claude-code/skills/lucind/SKILL.md

## Hard stops
No reliable marker distinguishes the main conversation from worker conversations in real transcripts.
Needing to edit a file outside the allowed edit surfaces.
Writing anything under ~/.gemini (transcripts are read-only evidence).

## Verification
golangci-lint run
CGO_ENABLED=0 go build ./...
go test ./... -race -count=1

## Known environmental failures
TestLaneIDFormat can fail once in a full run (known flaky); re-run it before treating it as a failure.

## Test-first policy
When a relevant runnable deterministic test and a clear expected outcome exist, observe RED
before implementing, then GREEN, then refactor while tests stay green. Runner: `go test`. Report
the RED and GREEN observations you actually saw; never invent them.

## Language contract
Generated technical artifacts (code, comments, tests, fixtures, docs) are in English.

## Size heuristic
About 400 authored changed lines is a planning heuristic only, not a cap. If the correct, clear
solution exceeds it, say why and continue. Never minify, drop tests or split artificially.

## Key Learnings
After writing your result envelope, close your final response with a `## Key Learnings` block of
1-5 numbered items, each a standalone factual sentence of at least 20 characters and 4 words;
omit it when there is genuinely no reusable learning.

---
## Lane Contract
- Lane ID: 20261005-043110-b7be
- Allowed globs:
  - internal/agyhook/**
  - internal/lane/lane.go
  - internal/lane/lane_test.go
  - internal/dispatch/dispatch.go
  - internal/dispatch/dispatch_test.go
  - cmd/lucind-ai/cli.go
  - cmd/lucind-ai/cli_test.go
  - cmd/lucind-ai/hook.go
  - cmd/lucind-ai/hook_test.go
  - docs/ROADMAP.md
  - plugin/claude-code/skills/lucind/SKILL.md
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261005-043110-b7be/result-1.json` following the result schema.
- As the final verification, after your last edit, run these commands exactly as listed and do not edit files afterwards:
  - `lucind-ai attest run -- sh -c 'golangci-lint run'`
  - `lucind-ai attest run -- sh -c 'CGO_ENABLED=0 go build ./...'`
  - `lucind-ai attest run -- sh -c 'go test ./... -race -count=1'`
- Do not edit outside the allowed globs.
