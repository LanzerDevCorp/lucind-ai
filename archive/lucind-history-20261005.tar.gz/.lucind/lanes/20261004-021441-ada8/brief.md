# Remove packet-era leftovers

## Goal
lucind-ai moved to an agy-only lane contract: the brief is free Markdown, there are no packets,
no SQLite ledger, no opencode/cursor/claude executors. Some tracked files still describe the old
packet model and confuse agents. Remove them and fix one stale description.

## Tasks
1. Delete with `git rm`:
   - `.agents/rules/lucind-lane-protocol.md`
   - `.agents/rules/lucind-write-scope.md`
   - `.agents/skills/` (all four skills: lucind-apply, lucind-executor, lucind-fan-out-lens, lucind-verify)
   - `.agents/hooks.json` (it is `{}`) and `.agents/scripts/` (unreferenced copies; the live hooks are in `scripts/hooks/`, do not touch those)
   - `.opencode/` (whole directory)
   - `backups/` (whole directory, includes an old SQLite ledger backup)
2. KEEP `.agents/rules/lucind-codegraph.md` unchanged.
3. Edit `.claude-plugin/marketplace.json`: rewrite only the two `description` fields so they match
   the current product: "Claude orchestrates, Antigravity (agy) implements through herdr, and
   lucind-ai enforces the deterministic lane contract (result envelope, allowed paths, test
   attestation)." Keep the top-level one a short one-liner and the plugin one slightly longer.
   Do not change names, version, source or any other field. Keep it valid JSON.

## Constraints
- Do not edit or delete anything else. If you find a file outside the allowed globs that
  references a deleted path, do not edit it: list it in `findings`.
- Do not commit.

## Hard stops
- A deletion would require editing a file outside the allowed globs to keep the build green.

## Done criteria
- All listed paths are gone; `lucind-codegraph.md` is intact.
- `marketplace.json` is valid JSON with only the descriptions changed.
- `lucind-ai attest run -- sh lucind-checks.sh` passes.

Report `files_changed`, `done_criteria` with evidence, and any `findings`.

---
## Lane Contract
- Lane ID: 20261004-021441-ada8
- Allowed globs:
  - .agents/**
  - .opencode/**
  - backups/**
  - .claude-plugin/marketplace.json
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261004-021441-ada8/result.json` following the result schema.
- As the final verification run exactly `lucind-ai attest run -- sh lucind-checks.sh` (accept only reuses an attestation of that exact command; otherwise it re-runs the checks).
- Do not edit outside the allowed globs.
