# T5b: document the per-turn result file

## Goal

The code now binds every result to its turn (tasks T1 to T4, already merged on this branch). The docs and the Claude skill still describe
a single `result.json`. Update them so they match the behavior. This is passive documentation: no Go code changes.

## Feature document

Read `odd/tasks/turn-bound-results.md` first. It is the source of truth for the behavior: objective, decisions, known residual.

## Behavior to document (facts, do not invent others)

- `lane.json` has `turn` (1 on create; incremented by every `dispatch --lane` continuation). Lanes created before this change have no
  `turn` (legacy): they keep using `result.json`; continuing one renames it to `result.prev.json` and the turn becomes 1.
- The result file of a turn is `.lucind/lanes/<id>/result-<turn>.json`. The brief footer and the `result_path` printed by `dispatch`
  and `wait` give the exact path. Earlier turns' files stay as history.
- Only the current turn's file is read by the Stop hook, `wait`, `accept` and `MarkStopped`. A valid result written by another turn is
  ignored: the Stop hook counts it as missing, `wait` does not report done, `accept` refuses.
- `wait` revalidates a `done` lane against the current turn file and reports failed (exit 3) if that file is missing or not done.
- PreToolUse denies writing any result file except the current turn's (besides the allowed globs rule).
- The Stop hook logs the raw payload as one `stop: raw payload ...` line (max 4096 bytes) in `.lucind/lanes/<id>/hook.log`, to find out
  whether agy sends a turn or conversation identifier.
- Known limit: a Stop from a previous turn that is still finishing cannot be told apart from a current one. It can spend a retry and
  inject the "write the envelope" nudge into the new turn. The retry budget resets after 60 s without a counted stop.
- Herdr idle is not reliable for agy (`agent prompt --wait` returned idle while agy was still working); completion is decided by the
  current turn's result file plus the Stop hook, not by idle.

## Files and what to change

- `README.md`, `CONTEXT.md`, `docs/product.md`: replace the single-`result.json` description with the per-turn file where they describe the
  current flow (product.md lines about the flow, the file table, PreToolUse and Stop). Add `turn` to the `lane.json` description if it is
  listed. Keep each edit minimal and in the file's existing style.
- `plugin/claude-code/skills/lucind/SKILL.md` (the Claude orchestrator skill): update the `result_path` mention, and rewrite the sentence
  about a continuation being "marked done early by the stale previous `result.json`": explain the per-turn file, that only the current
  turn counts, and the known limit above. Keep the rest.
- `internal/agyplugin/assets/plugin.json`: update only the `description` text that says "result.json validation".
- `docs/attestation.md`: line 94 describes an old worktree-era worker role with `.lucind/result.json`. Leave legacy text that does not
  describe the current lane flow untouched, and list it in the envelope `questions` or Key Learnings if you think it is stale.
- `docs/ROADMAP.md`: add a Done entry for this feature (per-turn result files: a lane is done only when the current turn delivered its
  file; Stop payload logging; deterministic lane ID test). Remove the Next items "Premature `done` on lane continuations" and "Flaky
  `TestLaneIDFormat`". Reword Next item "Idle detection": completion no longer depends on herdr idle; what remains is to read the raw
  Stop payloads in a few real lanes and, if agy sends a turn or conversation identifier, use it to ignore Stops from earlier turns.

## Skills to load before work

/home/lanzerdev/.agents/skills/cognitive-doc-design/SKILL.md

## Allowed edit surfaces

README.md
CONTEXT.md
docs/product.md
docs/attestation.md
docs/ROADMAP.md
plugin/claude-code/skills/lucind/SKILL.md
internal/agyplugin/assets/plugin.json

## Hard stops

A Go source file would need to change
A statement in the docs cannot be confirmed from the feature document or from reading the code
Any git write command would be needed (add, commit, stash, checkout, reset, rebase): never run them, the orchestrator commits

## Test-first policy

Passive documentation: there is no meaningful RED. Exception: run structural checks only. Confirm every edited file still reads well,
that no Go file changed (`git diff --stat`), and that the verification commands below pass.

## Verification

golangci-lint run
CGO_ENABLED=0 go build ./...
go test ./... -race -count=1

## Language contract

Docs in English, neutral and professional register.

## Size heuristic

About 400 authored changed lines per task is a planning heuristic only; this task should be far below it.

## Key Learnings

After writing the result envelope, close your final response with a `## Key Learnings` block of 1-5 numbered items, each a standalone factual sentence of at least 20 characters and at least 4 words. Omit it if there is no reusable learning.

---
## Lane Contract
- Lane ID: 20261005-011507-22a2
- Allowed globs:
  - README.md
  - CONTEXT.md
  - docs/product.md
  - docs/attestation.md
  - docs/ROADMAP.md
  - plugin/claude-code/skills/lucind/SKILL.md
  - internal/agyplugin/assets/plugin.json
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261005-011507-22a2/result-1.json` following the result schema.
- As the final verification, after your last edit, run these commands exactly as listed and do not edit files afterwards:
  - `lucind-ai attest run -- sh -c 'golangci-lint run'`
  - `lucind-ai attest run -- sh -c 'CGO_ENABLED=0 go build ./...'`
  - `lucind-ai attest run -- sh -c 'go test ./... -race -count=1'`
- Do not edit outside the allowed globs.
