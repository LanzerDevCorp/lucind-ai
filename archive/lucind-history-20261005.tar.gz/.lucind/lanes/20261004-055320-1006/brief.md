# T2: accept verifies the lane's own checks

Goal: `lucind-ai accept` must stop assuming `sh lucind-checks.sh` and instead verify exactly the
checks stored in the lane (`lane.json` `checks`, added in T1). Task T2 of the feature document.
Do only T2; T3 (deprecating `lucind-checks.sh` in docs, skills and help) and T4 (install) are
separate lanes.

## Feature document
odd/tasks/lane-checks-and-install.md

## Allowed edit surfaces
internal/accept/accept.go
internal/accept/accept_test.go
internal/lane/lane.go
internal/lane/lane_test.go
cmd/lucind-ai/cli.go
cmd/lucind-ai/cli_test.go

## Scope and design

Read the feature document first (decisions and constraints there are binding), then implement in
`internal/accept`:

1. Load the lane's `Checks`. For each check, the attested command string is
   `lane.CheckCommand(check)` (the helper from T1: `"sh -c " + check`). Look up a valid attestation
   for that exact command on the final tree with the existing `FindValidAttestation`.
2. For every check without a valid attestation, run only that check yourself on the final tree
   (`sh -c <check>` in the repo root), write its output to a log under the lane directory (one log
   per check, stable and unique file name), and treat a non-zero exit as a rejection reason that
   names the check. Checks that already have a valid attestation must not be re-run.
3. Zero checks: do not look up any attestation and run nothing. The verdict depends only on the
   result envelope and the allowed globs.
4. Receipt evidence: replace the single `{attestation, check_log}` evidence with a per-check list
   (each entry: the check, and either the attestation path or the check log path). An empty list
   for zero checks. Keep the receipt otherwise unchanged. If something outside the allowed edit
   surfaces consumes the old evidence shape, stop with `blocked` and name it.
5. Remove `accept`'s use of the hardcoded `"sh lucind-checks.sh"` and of `check.Check`. Do not edit
   or delete `internal/check`; its deprecation belongs to T3. Do not change deprecation wording,
   docs, skills or agy plugin assets either.
6. Update existing tests that pin the old behavior, and make them hermetic like the surrounding
   tests.

## Hard stops
- Any needed edit outside the allowed edit surfaces: stop with status `blocked` and say which path.
- The old evidence shape is consumed outside the allowed surfaces: stop with `blocked`.

## Test-first policy
Runner: `go test`. Observe RED first, then GREEN, then refactor. Cover at least: zero checks
accepted with no attestation and nothing run; one check with a valid attestation accepted without
running it; one check without attestation is run and accepted when it passes; a failing check is
rejected with a reason naming the check; two checks where only one is attested runs only the
missing one; receipt evidence lists one entry per check. Report RED and GREEN evidence per
behavior in `done_criteria[].evidence`. Never invent RED/GREEN evidence.

## Verification
go test ./internal/accept/... ./internal/lane/... ./cmd/lucind-ai/...
go vet ./...

## Language contract
Code, comments, tests and docs are in English.

## Size heuristic
About 400 authored changed lines is a planning heuristic only, not a cap or stop condition. Do not
omit tests, delete comments, or split artificially to fit it.

## Constraints
Match the style of the surrounding code. Do not commit; the parent commits after accept.

## Key Learnings
After writing the result envelope, persist your learnings with Engram `mem_save` and close your
final response with a `## Key Learnings` block of 1-5 numbered items, each a standalone factual
sentence of at least 20 characters and at least 4 words. Omit it when there is nothing reusable.

---
## Lane Contract
- Lane ID: 20261004-055320-1006
- Allowed globs:
  - internal/accept/accept.go
  - internal/accept/accept_test.go
  - internal/lane/lane.go
  - internal/lane/lane_test.go
  - cmd/lucind-ai/cli.go
  - cmd/lucind-ai/cli_test.go
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261004-055320-1006/result.json` following the result schema.
- As the final verification run exactly `lucind-ai attest run -- sh -c 'go test ./internal/accept/... ./internal/lane/... ./cmd/lucind-ai/...'` and do not edit files afterwards.
- As the final verification run exactly `lucind-ai attest run -- sh -c 'go vet ./...'` and do not edit files afterwards.
- Do not edit outside the allowed globs.
