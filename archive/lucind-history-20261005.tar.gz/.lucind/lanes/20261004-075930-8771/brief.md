# T15c: progress-aware retry budget in the Stop hook

Context (measured, see the T15 PROGRESS entry of the feature document). The Stop hook re-enters
agy (`continue`) when `result.json` is missing or invalid and fails the lane after `MaxRetries` (2)
spent retries. Real data from the hook log: Stops with `fullyIdle=false` (a subagent is running)
already cost nothing and that must not change. The problem is Stops with `fullyIdle=true` and no
result yet that are spread over minutes of real work (one lane burned its two retries 1m48s and 3s
apart while agy was still working), whereas a stuck agent answers within seconds (3 s and 7 s gaps
in a probe). Task T15c of the feature document. Do only T15c.

## Feature document
odd/tasks/lane-checks-and-install.md

## Allowed edit surfaces
internal/lane/lane.go
internal/lane/lane_test.go
internal/agyhook/agyhook.go
internal/agyhook/agyhook_test.go

## Scope and design

Read the T9, T14 and T15 entries of the feature document, `Stop` in `internal/agyhook/agyhook.go`
(note the existing payload logging) and the `Lane` struct in `internal/lane/lane.go`. Then:

1. **`lane.Lane`** gets two fields, both `omitempty`, so existing `lane.json` files stay valid:
   `LastStopAt *time.Time` (`last_stop_at`) and `Continues int` (`continues`). Add a round-trip
   test (with and without the fields) next to the existing lane JSON tests.
2. **`Stop`** (only the part after the `fullyIdle` early return and the lane/status checks; the
   `fullyIdle=false` path, the payload line and invalid-lane/invalid-JSON behavior stay exactly as
   they are). Add package-level constants `RetryQuietWindow = 60 * time.Second` and
   `MaxTotalContinues = 10`, and a package-level `var now = time.Now` so tests control the clock.
   When the result is missing or invalid:
   - If `LastStopAt` is set and `now() - *LastStopAt >= RetryQuietWindow`, reset `Retries` to 0 and
     log `stop: retry budget reset after <duration> without a counted stop`.
   - If `Retries < MaxRetries` and `Continues < MaxTotalContinues`: increment `Retries` and
     `Continues`, set `LastStopAt` to `now()`, save the lane, log the existing
     `stop: retry <n>/<MaxRetries>: <reason>` line and return the same `continue` response.
   - Otherwise (budget or total cap exhausted) mark the lane stopped as today, and make the final
     log line say which limit was hit (`retries` or `total continues`) next to the existing
     `lane marked <status>` text.
   - A valid result still goes straight to `MarkStopped` as today.
   Keep `MaxRetries = 2`.
3. Do not touch `wait`, `accept`, dispatch or any other file.

Out of scope: any change to what counts as a valid result, the payload line format, and any
heuristic based on `terminationReason` or `executionNum`.

## Hard stops
- Any needed edit outside the allowed edit surfaces: stop with status `blocked` and say which path.

## Test-first policy
Runner: `go test`. Observe RED first, then GREEN, then refactor. Drive `Stop` with synthetic JSON
payloads and a fake clock (`now`) over a temporary lane. Cover at least: two quick stops (a few
seconds apart) with no result exhaust the budget and the third marks the lane failed (current
behavior preserved); two stops separated by at least `RetryQuietWindow` do not exhaust it (the
budget resets and the lane stays running) and the reset line is logged; a sequence like
quick-slow-quick (as seen in a real lane: 1m48s then 3s) keeps the lane running; the total cap
`MaxTotalContinues` fails a lane even when every gap is longer than the window, and the log names
that limit; `fullyIdle=false` stops never change `Retries`, `Continues` or `LastStopAt`; a valid
result is marked done without touching the counters; `lane.json` without the new fields loads
and behaves like `Retries=0`. Report RED and GREEN evidence per behavior in
`done_criteria[].evidence`. Never invent RED/GREEN evidence.

## Verification
go test ./...
go vet ./...
test -z "$(gofmt -l .)"

## Language contract
Code, comments, tests and docs are in English.

## Size heuristic
About 400 authored changed lines is a planning heuristic only, not a cap or stop condition.

## Constraints
Match the style of the surrounding code and keep every Go file `gofmt`-clean. Do not commit; the
parent commits after accept.

## Key Learnings
After writing the result envelope, persist your learnings with Engram `mem_save` and close your
final response with a `## Key Learnings` block of 1-5 numbered items, each a standalone factual
sentence of at least 20 characters and at least 4 words. Omit it when there is nothing reusable.

---
## Lane Contract
- Lane ID: 20261004-075930-8771
- Allowed globs:
  - internal/lane/lane.go
  - internal/lane/lane_test.go
  - internal/agyhook/agyhook.go
  - internal/agyhook/agyhook_test.go
- Write your result envelope to `/home/lanzerdev/git_root/lucind-ai/.lucind/lanes/20261004-075930-8771/result.json` following the result schema.
- As the final verification, after your last edit, run these commands exactly as listed and do not edit files afterwards:
  - `lucind-ai attest run -- sh -c 'go test ./...'`
  - `lucind-ai attest run -- sh -c 'go vet ./...'`
  - `lucind-ai attest run -- sh -c 'test -z "$(gofmt -l .)"'`
- Do not edit outside the allowed globs.
